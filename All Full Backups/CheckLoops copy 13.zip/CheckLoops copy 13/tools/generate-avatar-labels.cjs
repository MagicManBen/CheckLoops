/* tools/generate-avatar-labels.cjs
   Purpose: Generate human-friendly labels for avatar part variants using DiceBear PNGs + OpenAI Vision.
   Defaults to *eyes only* so you can test cheaply, but you can pass categories.

   Usage examples:
     node tools/generate-avatar-labels.cjs                # eyes only, default model
     node tools/generate-avatar-labels.cjs eyes           # same as above
     node tools/generate-avatar-labels.cjs -m gpt-4o-mini eyes
     node tools/generate-avatar-labels.cjs -m gpt-4o-mini eyes mouth eyebrows
*/

const fs = require('node:fs/promises');

// ---------- CLI flags ----------
const argv = process.argv.slice(2);
function readFlag(name, alias) {
  const iLong = argv.indexOf(`--${name}`);
  if (iLong !== -1 && argv[iLong + 1] && !argv[iLong + 1].startsWith('-')) return argv[iLong + 1];
  const iShort = alias ? argv.indexOf(`-${alias}`) : -1;
  if (iShort !== -1 && argv[iShort + 1] && !argv[iShort + 1].startsWith('-')) return argv[iShort + 1];
  return null;
}

// ---------- API key (ENV first, then the provided demo key) ----------
const DEMO_KEY = "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";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || DEMO_KEY; // <-- used below

// Log (masked) so you can see whether ENV or fallback is used
const masked = OPENAI_API_KEY.length > 12
  ? OPENAI_API_KEY.slice(0, 6) + "…" + OPENAI_API_KEY.slice(-6)
  : "(short/unknown)";
console.log(`Using API key: ${process.env.OPENAI_API_KEY ? "ENV" : "EMBEDDED"} (${masked})`);

// ---------- Model ----------
const model = readFlag('model', 'm') || process.env.OPENAI_MODEL || 'gpt-4o-mini';
console.log(`Model: ${model}`);

// ---------- Categories ----------
// Keep eyes by default (cheap test), but you can pass: eyes mouth eyebrows glasses earrings hair
const variants = {
  eyes: Array.from({ length: 26 }, (_, i) => `variant${String(i + 1).padStart(2, '0')}`),
  mouth: Array.from({ length: 30 }, (_, i) => `variant${String(i + 1).padStart(2, '0')}`),
  eyebrows: Array.from({ length: 15 }, (_, i) => `variant${String(i + 1).padStart(2, '0')}`),
  glasses: Array.from({ length: 5 },  (_, i) => `variant${String(i + 1).padStart(2, '0')}`),
  earrings: Array.from({ length: 6 },  (_, i) => `variant${String(i + 1).padStart(2, '0')}`),
  hair: [
    ...Array.from({ length: 19 }, (_, i) => `short${String(i + 1).padStart(2, '0')}`),
    ...Array.from({ length: 26 }, (_, i) => `long${String(i + 1).padStart(2, '0')}`),
  ],
};
const allowed = Object.keys(variants);
const requested = argv.filter(a => allowed.includes(a));
const categories = requested.length ? requested : ['eyes'];
console.log(`Categories: ${categories.join(', ')}`);

// ---------- Helpers ----------
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const sleep = ms => new Promise(r => setTimeout(r, ms));

function fallbackLabel(category, key) {
  const mVar = key.match(/^variant(\d{2})$/);
  if (mVar) return `${cap(category)} Style ${Number(mVar[1])}`;
  const mHair = key.match(/^(short|long)(\d{2})$/);
  if (mHair) return `${mHair[1] === 'short' ? 'Short' : 'Long'} ${Number(mHair[2])}`;
  return `${cap(category)} ${key}`;
}

function dicebearPngUrl(category, key) {
  const u = new URL('https://api.dicebear.com/7.x/adventurer/png');
  // Neutral baseline so target part stands out
  u.searchParams.set('seed', 'labeler');
  u.searchParams.set('backgroundColor', 'ffffff');
  u.searchParams.set('radius', '0');
  u.searchParams.set('eyes', 'variant01');
  u.searchParams.set('mouth', 'variant01');
  u.searchParams.set('eyebrows', 'variant01');
  u.searchParams.set('glasses', 'variant01');
  u.searchParams.set('earrings', 'variant01');
  u.searchParams.set('features', '');
  u.searchParams.set('glassesProbability', '0');
  u.searchParams.set('earringsProbability', '0');
  u.searchParams.set('featuresProbability', '0');
  u.searchParams.set('hairProbability', '0'); // avoid occluding the eyes
  // Apply the variant we’re labeling
  u.searchParams.set(category, key);
  return u.toString();
}

async function pngDataUrl(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`DiceBear ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  return `data:image/png;base64,${buf.toString('base64')}`;
}

async function askOpenAI(imageDataUrl, category, key) {
  const sys = 'You are labeling avatar parts. Reply ONLY valid JSON: {"label":"2-3 words","keywords":["k1","k2"]}';
  const userText = `Name this ${category} option '${key}' in 2-3 concise, human-friendly words.`;

  const body = {
    model,
    messages: [
      { role: "system", content: sys },
      { role: "user", content: [
          { type: "text", text: userText },
          { type: "image_url", image_url: { url: imageDataUrl } }
        ] }
    ],
    temperature: 0.2,
  };

  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`, // <-- the key is used here
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`OpenAI ${resp.status}: ${errText}`);
  }

  const data = await resp.json();
  const content = data.choices?.[0]?.message?.content?.trim() || "";
  let parsed;
  try { parsed = JSON.parse(content); } catch {}
  if (!parsed || typeof parsed !== 'object' || !parsed.label) {
    return { label: fallbackLabel(category, key), keywords: [] };
  }
  if (!Array.isArray(parsed.keywords)) parsed.keywords = [];
  return parsed;
}

// ---------- Main ----------
async function main() {
  const outJsonPath = 'avatar_labels.generated.json';
  const outSqlPath = 'avatar_option_labels.sql';

  const total = categories.reduce((n, c) => n + (variants[c]?.length || 0), 0);
  console.log(`Labeling ${total} variants across: ${categories.join(', ')}`);

  const results = [];

  for (const cat of categories) {
    for (const key of variants[cat]) {
      try {
        const imgDataUrl = await pngDataUrl(dicebearPngUrl(cat, key));
        const { label, keywords } = await askOpenAI(imgDataUrl, cat, key);
        results.push({ option_id: `opt-${cat}`, value_key: key, label, keywords });
        console.log(`OK ${cat}:${key} -> ${label}`);
        await sleep(150); // gentle pacing
      } catch (e) {
        console.error(`Failed ${cat}:${key} -> ${e.message}`);
      }
    }
  }

  // Write JSON
  await fs.writeFile(outJsonPath, JSON.stringify(results, null, 2), 'utf8');

  // Write SQL (create table + upserts)
  let sql = `
create table if not exists public.avatar_option_labels (
  id bigserial primary key,
  option_id text not null,
  value_key text not null,
  label text not null,
  keywords text[] default '{}',
  unique (option_id, value_key)
);
`.trim();

  for (const r of results) {
    const kw = `{${r.keywords.map(k => `"${String(k).replace(/"/g,'\\"')}"`).join(',')}}`;
    const labelEsc = r.label.replace(/'/g, "''");
    sql += `
insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('${r.option_id}', '${r.value_key}', '${labelEsc}', '${kw}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;`.trim();
  }
  sql += '\n';

  await fs.writeFile(outSqlPath, sql, 'utf8');

  console.log(`\nWrote ${results.length} labels to:\n  - ${outJsonPath}\n  - ${outSqlPath}\nNext: pbcopy < ${outSqlPath}  # then paste into Supabase SQL editor and Run.`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
