-- Enable Row Level Security on tables that don't have it
-- Run this script in the Supabase SQL Editor

-- Enable RLS on ai_jobs table
ALTER TABLE public.ai_jobs ENABLE ROW LEVEL SECURITY;

-- Enable RLS on surgery_settings table  
ALTER TABLE public.surgery_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for ai_jobs table
-- Allow users to see their own AI jobs
CREATE POLICY "Users can view their own AI jobs" ON public.ai_jobs
    FOR SELECT USING (auth.uid() = user_id);

-- Allow users to create their own AI jobs
CREATE POLICY "Users can create their own AI jobs" ON public.ai_jobs
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Allow users to update their own AI jobs
CREATE POLICY "Users can update their own AI jobs" ON public.ai_jobs
    FOR UPDATE USING (auth.uid() = user_id);

-- Create policies for surgery_settings table
-- Allow authenticated users from the same site to view settings
CREATE POLICY "Users can view settings for their site" ON public.surgery_settings
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE profiles.user_id = auth.uid()
            AND profiles.site_id = surgery_settings.site_id
        )
    );

-- Only admin users can insert/update/delete surgery settings
CREATE POLICY "Admin users can manage surgery settings" ON public.surgery_settings
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles
            WHERE profiles.user_id = auth.uid()
            AND profiles.site_id = surgery_settings.site_id
            AND profiles.role = 'admin'
        )
    );

-- Verify RLS is enabled on all tables
SELECT 
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;