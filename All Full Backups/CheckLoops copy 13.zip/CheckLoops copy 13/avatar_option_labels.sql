create table if not exists public.avatar_option_labels (
  id bigserial primary key,
  option_id text not null,
  value_key text not null,
  label text not null,
  keywords text[] default '{}',
  unique (option_id, value_key)
);
