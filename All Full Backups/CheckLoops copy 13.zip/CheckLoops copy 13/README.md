# CheckLoop

A web-based checking and tracking system built with Supabase.

## Demo
Visit the live demo at: https://magicmanben.github.io/CheckLoops/

## Features
- User invitation system
- Password management
- Admin dashboard
- Real-time data with Supabase


