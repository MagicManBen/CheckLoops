-- 1) Create achievements master table
CREATE TABLE IF NOT EXISTS public.achievements (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  points INTEGER DEFAULT 0,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 2) Create user_achievements tracker table
CREATE TABLE IF NOT EXISTS public.user_achievements (
  id BIGSERIAL PRIMARY KEY,
  kiosk_user_id INTEGER NOT NULL,
  achievement_key TEXT NOT NULL REFERENCES public.achievements(key) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'locked',
  progress_percent NUMERIC(5,2) DEFAULT 0,
  progress_details JSONB DEFAULT '{}'::jsonb,
  unlocked_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (kiosk_user_id, achievement_key)
);

-- Helpful indexes
CREATE INDEX IF NOT EXISTS idx_user_achievements_kiosk_user_id ON public.user_achievements (kiosk_user_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_achievement_key ON public.user_achievements (achievement_key);

-- Enforce status values
ALTER TABLE public.user_achievements
  ADD CONSTRAINT chk_user_achievements_status
  CHECK (status IN ('locked','in_progress','unlocked'));

-- 3) Insert canonical achievements
INSERT INTO public.achievements (key, name, description, icon, points, metadata)
VALUES
  ('first_login', 'First Login', 'Awarded on first staff login to the app.', 'star', 10, '{"category":"milestone"}'),
  ('on_time_submission', 'On-Time Submission', 'Submit on time for a scheduled check.', 'clock', 5, '{"category":"behavior"}'),
  ('seven_day_streak', '7-Day Streak', 'Submit at least once per day for 7 consecutive days.', 'calendar', 25, '{"category":"streak"}'),
  ('training_complete', 'Training Complete', 'Completed 100% of required training modules.', 'certificate', 20, '{"category":"training"}')
ON CONFLICT (key) DO NOTHING;

-- 4) Seed tracker rows for all existing kiosk_users
INSERT INTO public.user_achievements (kiosk_user_id, achievement_key, status, progress_percent, created_at)
SELECT k.id AS kiosk_user_id, a.key AS achievement_key, 'locked'::text, 0::numeric, now()
FROM public.kiosk_users k
CROSS JOIN public.achievements a
LEFT JOIN public.user_achievements ua
  ON ua.kiosk_user_id = k.id AND ua.achievement_key = a.key
WHERE ua.id IS NULL;

-- 5) Upsert function
CREATE OR REPLACE FUNCTION public.upsert_user_achievement(
  p_kiosk_user_id INTEGER,
  p_achievement_key TEXT,
  p_status TEXT,
  p_progress_percent NUMERIC DEFAULT NULL,
  p_progress_details JSONB DEFAULT NULL
)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO public.user_achievements (kiosk_user_id, achievement_key, status, progress_percent, progress_details, unlocked_at, created_at)
  VALUES (
    p_kiosk_user_id,
    p_achievement_key,
    p_status,
    COALESCE(p_progress_percent, 0),
    COALESCE(p_progress_details, '{}'::jsonb),
    CASE WHEN p_status = 'unlocked' THEN now() ELSE NULL END,
    now()
  )
  ON CONFLICT (kiosk_user_id, achievement_key) DO UPDATE
  SET
    progress_percent = GREATEST(
      COALESCE(public.user_achievements.progress_percent, 0),
      COALESCE(EXCLUDED.progress_percent, public.user_achievements.progress_percent)
    ),
    progress_details = CASE
      WHEN EXCLUDED.progress_details IS NOT NULL THEN jsonb_strip_nulls(public.user_achievements.progress_details || EXCLUDED.progress_details)
      ELSE public.user_achievements.progress_details
    END,
    status = CASE
      WHEN public.user_achievements.status = 'unlocked' THEN public.user_achievements.status
      ELSE EXCLUDED.status
    END,
    unlocked_at = CASE
      WHEN EXCLUDED.status = 'unlocked' AND public.user_achievements.unlocked_at IS NULL THEN now()
      ELSE public.user_achievements.unlocked_at
    END;
END;
$$;