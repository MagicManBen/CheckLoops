// Direct session check for admin page
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Parse URL parameters to check if we're coming from staff page
    const urlParams = new URLSearchParams(window.location.search);
    const fromStaff = urlParams.get('from') === 'staff';
    
    if (fromStaff) {
      console.log('🔄 Navigation detected from staff page to admin');
      // Remove the query parameter to clean up the URL without refreshing
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    // Create Supabase client
    const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
    const supabase = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' }
    });

    // Check if user is authenticated
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session) {
      console.log('🔒 No authenticated session detected, redirecting to login');
      window.location.href = 'Home.html?redirect=admin';
      return;
    }

    console.log('✅ User authenticated:', session.user.email);
    
    // Force a session refresh to ensure we have the latest token
    if (fromStaff) {
      const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
      if (refreshError) {
        console.error('❌ Session refresh failed:', refreshError);
      } else {
        console.log('✅ Session refreshed successfully after staff navigation');
      }
    }
    
    // Check if user has admin privileges
    const checkAdminAccess = async () => {
      try {
        // Check profile role
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('role')
          .eq('user_id', session.user.id)
          .maybeSingle();
        
        if (profile && ['admin', 'owner'].includes(profile.role?.toLowerCase())) {
          console.log('✅ Admin access confirmed from profile');
          return true;
        }
        
        // Check invitations
        const { data: invite, error: inviteError } = await supabase
          .from('site_invites')
          .select('role')
          .eq('email', session.user.email)
          .in('role', ['admin', 'owner'])
          .maybeSingle();
          
        if (invite) {
          console.log('✅ Admin access confirmed from invitation');
          return true;
        }
        
        // Check user metadata
        const rawRole = session.user?.user_metadata?.role || 
                       session.user?.raw_user_meta_data?.role || 
                       session.user?.app_metadata?.role;
                       
        if (rawRole && ['admin', 'owner'].includes(String(rawRole).toLowerCase())) {
          console.log('✅ Admin access confirmed from user metadata');
          return true;
        }
        
        return false;
      } catch (err) {
        console.error('Error checking admin access:', err);
        return false;
      }
    };
    
    const hasAdminAccess = await checkAdminAccess();
    
    if (!hasAdminAccess) {
      console.log('⛔ User is authenticated but lacks admin access');
      setTimeout(() => {
        const adminSection = document.getElementById('admin-section');
        const staffView = document.getElementById('staff-view');
        const noAccess = document.getElementById('no-access');
        
        if (adminSection) adminSection.style.display = 'none';
        if (staffView) staffView.style.display = 'block';
        if (noAccess) noAccess.style.display = 'block';
        
        // If we came from staff page, give option to go back
        if (fromStaff) {
          alert('You do not have admin access privileges');
          window.location.href = 'staff.html';
        }
      }, 300);
    } else {
      console.log('✅ Admin access confirmed, bootstrapping admin interface');
      // Make admin status available to any scripts that need it
      window._adminSessionChecked = true;
      // The initAuth function will handle the rest
    }
  } catch (err) {
    console.error('❌ Session check exception:', err);
    // On any critical error, redirect to login
    window.location.href = 'Home.html?redirect=admin';
  }
});
