import { chromium } from 'playwright';

async function diagnoseBenAdminIssue() {
  console.log('🔍 Comprehensive diagnosis of ben.howard@stoke.nhs.uk admin issue...\n');
  
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();
  
  try {
    // Set up console logging
    page.on('console', msg => {
      if (msg.text().includes('requireStaffSession') || 
          msg.text().includes('role') || 
          msg.text().includes('admin') || 
          msg.text().includes('revealAdminNav')) {
        console.log('🎯 Browser:', msg.text());
      }
    });
    
    console.log('1️⃣ Opening login page...');
    await page.goto('http://localhost:8001/Home.html');
    await page.waitForTimeout(2000);
    
    console.log('2️⃣ Logging in as ben.howard@stoke.nhs.uk...');
    await page.locator('#email').fill('ben.howard@stoke.nhs.uk');
    await page.locator('#password').fill('Hello1!');
    await page.click('button:has-text("Sign In")');
    await page.waitForTimeout(5000);
    
    const currentUrl = page.url();
    console.log('🔗 Redirected to:', currentUrl);
    
    // Wait for page to fully load
    await page.waitForTimeout(3000);
    
    console.log('\n3️⃣ Extracting authentication data...');
    
    const authData = await page.evaluate(async () => {
      try {
        const { initSupabase } = await import('./staff-common.js');
        const supabase = await initSupabase();
        
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) return { error: 'No session' };
        
        // Get all relevant data
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', session.user.id)
          .maybeSingle();
        
        const { data: saw } = await supabase
          .from('staff_app_welcome')
          .select('*')
          .eq('user_id', session.user.id)
          .maybeSingle();
        
        return {
          userId: session.user.id,
          email: session.user.email,
          rawMetaData: session.user.raw_user_meta_data,
          profile: profile,
          staffAppWelcome: saw
        };
      } catch (error) {
        return { error: error.message };
      }
    });
    
    console.log('\n📊 AUTHENTICATION DATA:');
    console.log('========================');
    console.log('User ID:', authData.userId);
    console.log('Email:', authData.email);
    console.log('Raw Meta Role:', authData.rawMetaData?.role);
    console.log('Raw Meta Role Detail:', authData.rawMetaData?.role_detail);
    console.log('Profile Role:', authData.profile?.role);
    console.log('Profile Full Name:', authData.profile?.full_name);
    console.log('SAW Nickname:', authData.staffAppWelcome?.nickname);
    console.log('SAW Role Detail:', authData.staffAppWelcome?.role_detail);
    
    if (authData.error) {
      console.log('❌ Error getting auth data:', authData.error);
    }
    
    console.log('\n4️⃣ Testing role logic...');
    
    const roleTests = await page.evaluate(async () => {
      try {
        const { initSupabase, requireStaffSession } = await import('./staff-common.js');
        const supabase = await initSupabase();
        
        const { data: { session } } = await supabase.auth.getSession();
        const { data: profileRow } = await supabase
          .from('profiles')
          .select('role, full_name, site_id')
          .eq('user_id', session.user.id)
          .maybeSingle();
        
        // Test requireStaffSession logic
        const role = profileRow?.role || session.user?.raw_user_meta_data?.role || null;
        const allowed = ['staff', 'admin', 'owner', 'manager'];
        const isAllowed = role && allowed.includes(String(role).toLowerCase());
        
        // Test admin nav logic
        const r = String(role || '').toLowerCase();
        const shouldShowAdminNav = (r === 'admin' || r === 'owner');
        
        // Test what's actually displayed
        const roleDetailDisplayed = session.user?.raw_user_meta_data?.role_detail || 'Staff';
        
        return {
          resolvedRole: role,
          isAllowed: isAllowed,
          shouldShowAdminNav: shouldShowAdminNav,
          roleDetailDisplayed: roleDetailDisplayed,
          allowedRoles: allowed
        };
      } catch (error) {
        return { error: error.message };
      }
    });
    
    console.log('🔐 ROLE LOGIC TESTS:');
    console.log('===================');
    console.log('Resolved Role:', roleTests.resolvedRole);
    console.log('Is Allowed:', roleTests.isAllowed);
    console.log('Should Show Admin Nav:', roleTests.shouldShowAdminNav);
    console.log('Role Detail Displayed:', roleTests.roleDetailDisplayed);
    console.log('Allowed Roles:', roleTests.allowedRoles);
    
    console.log('\n5️⃣ Checking actual page display...');
    
    // Check what's displayed in the UI
    const uiState = await page.evaluate(() => {
      const rolePill = document.getElementById('role-pill');
      const adminLinks = document.querySelectorAll('.admin-only');
      
      return {
        rolePillText: rolePill?.textContent || 'Not found',
        adminLinksCount: adminLinks.length,
        adminLinksVisible: Array.from(adminLinks).filter(el => 
          el.style.display !== 'none' && 
          el.offsetParent !== null
        ).length
      };
    });
    
    console.log('🖥️ UI STATE:');
    console.log('=============');
    console.log('Role Pill Text:', uiState.rolePillText);
    console.log('Admin Links Total:', uiState.adminLinksCount);
    console.log('Admin Links Visible:', uiState.adminLinksVisible);
    
    // Check if user can access index.html
    console.log('\n6️⃣ Testing admin page access...');
    await page.goto('http://localhost:8001/index.html');
    await page.waitForTimeout(3000);
    
    const adminUrl = page.url();
    console.log('🔗 Admin page URL:', adminUrl);
    
    if (adminUrl.includes('index.html')) {
      console.log('✅ Can access admin page (index.html)');
    } else {
      console.log('❌ Redirected away from admin page to:', adminUrl);
    }
    
    // Apply fixes if needed
    console.log('\n7️⃣ Applying fixes...');
    
    const fixResult = await page.evaluate(async () => {
      try {
        const { initSupabase } = await import('./staff-common.js');
        const supabase = await initSupabase();
        
        const { data: { session } } = await supabase.auth.getSession();
        const userId = session.user.id;
        
        // Fix 1: Update profiles
        const { error: profileError } = await supabase
          .from('profiles')
          .update({ role: 'admin' })
          .eq('user_id', userId);
        
        // Fix 2: Update auth meta data
        const newMetaData = {
          ...session.user.raw_user_meta_data,
          role: 'admin',
          role_detail: 'Admin'
        };
        
        const { error: authError } = await supabase.auth.updateUser({
          data: newMetaData
        });
        
        // Fix 3: Update staff_app_welcome
        const { error: sawError } = await supabase
          .from('staff_app_welcome')
          .update({ 
            nickname: 'Ben',
            role_detail: 'Admin'
          })
          .eq('user_id', userId);
        
        return {
          profileFixed: !profileError,
          authFixed: !authError,
          sawFixed: !sawError,
          errors: { profileError, authError, sawError }
        };
      } catch (error) {
        return { error: error.message };
      }
    });
    
    console.log('🔧 FIX RESULTS:');
    console.log('===============');
    console.log('Profiles Fixed:', fixResult.profileFixed);
    console.log('Auth Fixed:', fixResult.authFixed);
    console.log('SAW Fixed:', fixResult.sawFixed);
    if (fixResult.errors) {
      Object.entries(fixResult.errors).forEach(([key, error]) => {
        if (error) console.log(`${key}:`, error);
      });
    }
    
    console.log('\n8️⃣ Refreshing page to test fixes...');
    await page.reload();
    await page.waitForTimeout(3000);
    
    // Re-test after fixes
    const afterFixUrl = page.url();
    console.log('🔗 URL after refresh:', afterFixUrl);
    
    await page.screenshot({ path: 'ben_admin_diagnosis.png' });
    console.log('\n📸 Screenshot saved: ben_admin_diagnosis.png');
    
    console.log('\n✅ Diagnosis complete!');
    
  } catch (error) {
    console.error('❌ Diagnosis failed:', error);
    await page.screenshot({ path: 'diagnosis_error.png' });
  } finally {
    await browser.close();
  }
}

// Run the diagnosis
diagnoseBenAdminIssue();
