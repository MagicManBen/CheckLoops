-- SQL script to add benhowardmagic@hotmail.com as an admin user
-- This creates the user in auth.users and populates all related tables

-- Step 1: Insert into auth.users (this creates the authentication record)
-- Note: In a real Supabase environment, you'd typically invite the user through the dashboard
-- or use the admin API, but this shows the data structure needed

-- Generate a UUID for the new user (you may want to use a specific UUID)
-- For consistency, let's use a predictable UUID: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'

INSERT INTO auth.users (
  id,
  instance_id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  invited_at,
  confirmation_token,
  confirmation_sent_at,
  recovery_token,
  recovery_sent_at,
  email_change_token_new,
  email_change,
  email_change_sent_at,
  last_sign_in_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  created_at,
  updated_at,
  phone,
  phone_confirmed_at,
  phone_change,
  phone_change_token,
  phone_change_sent_at,
  email_change_token_current,
  email_change_confirm_status,
  banned_until,
  deleted_at,
  is_sso_user,
  is_anonymous
) VALUES (
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid,
  '00000000-0000-0000-0000-000000000000'::uuid,
  'authenticated',
  'authenticated',
  'benhowardmagic@hotmail.com',
  '$2a$10$fSxQHF1qXXdJsPB3Wa5H2OuMUUguvxgUlk5HphMRH6eWVwXNNgtq2', -- This is the hash for 'Hello1!'
  now(),
  now(),
  '',
  null,
  '',
  null,
  '',
  '',
  null,
  now(),
  '{"provider": "email", "providers": ["email"]}'::jsonb,
  '{
    "role": "admin",
    "site_id": 2,
    "nickname": "Ben",
    "full_name": "Ben Howard",
    "role_detail": "Admin",
    "email_verified": true,
    "avatar_url": "https://api.dicebear.com/7.x/adventurer/svg?seed=Ben&backgroundType=solid&backgroundColor=ffffff&backgroundRotation=0&radius=0&rotate=0&scale=100&flip=false&clip=false&translateX=0&translateY=0&eyes=variant01&mouth=variant01&eyebrows=variant01&glasses=variant01&glassesProbability=100&earrings=variant01&earringsProbability=0&features=freckles&featuresProbability=100&hair=long01&hairColor=0e0e0e&hairProbability=100&skinColor=f2d3b1"
  }'::jsonb,
  false,
  now(),
  now(),
  null,
  null,
  '',
  '',
  null,
  '',
  0,
  null,
  null,
  false,
  false
);

-- Step 2: Insert into auth.identities
INSERT INTO auth.identities (
  id,
  user_id,
  identity_data,
  provider,
  provider_id,
  last_sign_in_at,
  created_at,
  updated_at
) VALUES (
  gen_random_uuid(),
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid,
  '{
    "sub": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "email": "benhowardmagic@hotmail.com",
    "email_verified": true,
    "phone_verified": false
  }'::jsonb,
  'email',
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
  now(),
  now(),
  now()
);

-- Step 3: Insert into public.profiles
INSERT INTO public.profiles (
  user_id,
  role,
  full_name,
  nickname,
  site_id,
  org_id,
  created_at,
  next_quiz_due
) VALUES (
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid,
  'admin',
  'Ben Howard',
  'Ben Howard',
  2,
  null,
  now(),
  now() + interval '7 days'
);

-- Step 4: Insert into public.staff_app_welcome
INSERT INTO public.staff_app_welcome (
  user_id,
  site_id,
  full_name,
  nickname,
  role_detail,
  team_id,
  team_name,
  avatar_url,
  created_at,
  updated_at
) VALUES (
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid,
  2,
  'Ben Howard',
  'Ben',
  'Admin',
  12, -- Assuming Managers team has ID 12 based on SupabaseInfo.txt
  'Managers',
  'https://api.dicebear.com/7.x/adventurer/svg?seed=Ben&backgroundType=solid&backgroundColor=ffffff&backgroundRotation=0&radius=0&rotate=0&scale=100&flip=false&clip=false&translateX=0&translateY=0&eyes=variant01&mouth=variant01&eyebrows=variant01&glasses=variant01&glassesProbability=100&earrings=variant01&earringsProbability=0&features=freckles&featuresProbability=100&hair=long01&hairColor=0e0e0e&hairProbability=100&skinColor=f2d3b1',
  now(),
  now()
);

-- Step 5: Insert into public.kiosk_users (if this table exists based on your schema)
-- This table appears to be for kiosk PIN-based access, not linked to auth.users
-- Based on the schema, it has: id, pin, role, active, site_id, team_id, pin_hash, pin_hmac, full_name, team_name, created_at, reports_to_id
-- We'll skip this table since it's not directly linked to auth users and requires PIN setup

-- INSERT INTO public.kiosk_users (
--   role,
--   active,
--   site_id,
--   team_id,
--   full_name,
--   team_name,
--   created_at,
--   reports_to_id
-- ) VALUES (
--   'Admin',
--   true,
--   2,
--   12,
--   'Ben Howard',
--   'Managers',
--   now(),
--   null
-- ) ON CONFLICT DO NOTHING; -- Skip if table structure differs

-- Step 6: Insert into public.staff_directory (table does not exist, skipping)
-- INSERT INTO public.staff_directory - this table doesn't exist in the current schema

-- Verification queries to check the user was created correctly
SELECT 'auth.users verification' as table_name, 
       id, email, 
       raw_user_meta_data->>'role' as role,
       raw_user_meta_data->>'role_detail' as role_detail
FROM auth.users 
WHERE email = 'benhowardmagic@hotmail.com';

SELECT 'public.profiles verification' as table_name,
       user_id, role, full_name, nickname, site_id
FROM public.profiles 
WHERE user_id = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid;

SELECT 'public.staff_app_welcome verification' as table_name,
       user_id, nickname, role_detail, team_name, site_id
FROM public.staff_app_welcome 
WHERE user_id = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'::uuid;

-- Grant necessary permissions (if using RLS)
-- These might be needed depending on your RLS policies
-- GRANT USAGE ON SCHEMA public TO authenticated;
-- GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;

-- Note: To complete the setup, you may also need to:
-- 1. Set up any custom user metadata through the Supabase dashboard
-- 2. Configure any additional app-specific data
-- 3. Test login with email: benhowardmagic@hotmail.com, password: Hello1!
