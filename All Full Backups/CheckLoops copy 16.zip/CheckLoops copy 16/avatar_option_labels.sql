create table if not exists public.avatar_option_labels (
  id bigserial primary key,
  option_id text not null,
  value_key text not null,
  label text not null,
  keywords text[] default '{}',
  unique (option_id, value_key)
);insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'short07', 'Vibrant Short Hair', '{"green","short","stylish"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'short08', 'Playful Short Cut', '{"playful","short","cut"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'short09', 'Charming Short Style', '{"short","green","playful"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'long12', 'Chic Green Updo', '{"green","updo","chic"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'long13', 'Twisted Green Buns', '{"green","buns","twisted"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;insert into public.avatar_option_labels (option_id, value_key, label, keywords)
values ('opt-hair', 'long14', 'Playful Green Pigtails', '{"green","pigtails","playful"}')
on conflict (option_id, value_key)
do update set label = excluded.label, keywords = excluded.keywords;
