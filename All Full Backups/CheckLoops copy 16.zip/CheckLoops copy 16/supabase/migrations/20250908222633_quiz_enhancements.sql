-- Quiz System Enhancements
-- Create Quiz_Practices table for practice quiz tracking

CREATE TABLE IF NOT EXISTS public.quiz_practices (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    site_id BIGINT REFERENCES public.sites(id) ON DELETE SET NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    score_percent INTEGER,
    score INTEGER DEFAULT 0,
    total_questions INTEGER DEFAULT 0,
    answers JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE public.quiz_practices ENABLE ROW LEVEL SECURITY;

-- Users can insert their own practice records
CREATE POLICY "quiz_practices_insert_own" ON public.quiz_practices
    FOR INSERT TO authenticated
    WITH CHECK (user_id = auth.uid());

-- Users can view their own practice records
CREATE POLICY "quiz_practices_select_own" ON public.quiz_practices
    FOR SELECT TO authenticated
    USING (user_id = auth.uid());

-- Add new quiz achievements to achievements table
INSERT INTO public.achievements (key, name, description, icon, points, metadata) VALUES
('quiz_complete', 'Quiz Master', 'Complete your weekly mandatory quiz', 'brain', 15, '{"category": "behavior"}'::jsonb),
('quiz_perfect', 'Perfect Score', 'Get 100% on a quiz', 'star', 25, '{"category": "achievement"}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Update profiles table to ensure next_quiz_due exists
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS next_quiz_due TIMESTAMPTZ;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_quiz_practices_user_id ON public.quiz_practices(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_practices_site_id ON public.quiz_practices(site_id);
CREATE INDEX IF NOT EXISTS idx_quiz_practices_completed_at ON public.quiz_practices(completed_at);

-- Update quiz_attempts table to ensure is_practice column exists
ALTER TABLE public.quiz_attempts 
ADD COLUMN IF NOT EXISTS is_practice BOOLEAN DEFAULT FALSE;

-- Add index for quiz_attempts
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_user_id ON public.quiz_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_attempts_is_practice ON public.quiz_attempts(is_practice);