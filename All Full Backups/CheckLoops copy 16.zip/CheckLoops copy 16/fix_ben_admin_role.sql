-- SQL script to fix ben.howard@stoke.nhs.uk role issues
-- Run this against the remote Supabase database

-- First, let's check the current state
SELECT 
  'auth.users' as table_name,
  id as user_id,
  email,
  raw_user_meta_data->>'role' as role,
  raw_user_meta_data->>'role_detail' as role_detail
FROM auth.users 
WHERE email = 'ben.howard@stoke.nhs.uk';

SELECT 
  'public.profiles' as table_name,
  user_id,
  role,
  full_name,
  site_id
FROM public.profiles p
JOIN auth.users u ON p.user_id = u.id
WHERE u.email = 'ben.howard@stoke.nhs.uk';

SELECT 
  'public.staff_app_welcome' as table_name,
  user_id,
  nickname,
  role_detail,
  team_name,
  site_id
FROM public.staff_app_welcome saw
JOIN auth.users u ON saw.user_id = u.id
WHERE u.email = 'ben.howard@stoke.nhs.uk';

-- Fix 1: Ensure the profiles table has the correct admin role
UPDATE public.profiles 
SET role = 'admin'
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'ben.howard@stoke.nhs.uk'
);

-- Fix 2: Update the auth.users raw_user_meta_data to ensure role is admin
UPDATE auth.users 
SET raw_user_meta_data = raw_user_meta_data || '{"role": "admin"}'::jsonb
WHERE email = 'ben.howard@stoke.nhs.uk';

-- Fix 3: Clean up the staff_app_welcome nickname that suggests this is a staff account
UPDATE public.staff_app_welcome 
SET nickname = 'Ben'
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'ben.howard@stoke.nhs.uk'
);

-- Fix 4: Ensure role_detail is appropriate for an admin
UPDATE public.staff_app_welcome 
SET role_detail = 'Admin'
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'ben.howard@stoke.nhs.uk'
);

-- Verify the fixes
SELECT 
  'AFTER FIX - auth.users' as table_name,
  id as user_id,
  email,
  raw_user_meta_data->>'role' as role,
  raw_user_meta_data->>'role_detail' as role_detail
FROM auth.users 
WHERE email = 'ben.howard@stoke.nhs.uk';

SELECT 
  'AFTER FIX - public.profiles' as table_name,
  user_id,
  role,
  full_name,
  site_id
FROM public.profiles p
JOIN auth.users u ON p.user_id = u.id
WHERE u.email = 'ben.howard@stoke.nhs.uk';

SELECT 
  'AFTER FIX - public.staff_app_welcome' as table_name,
  user_id,
  nickname,
  role_detail,
  team_name,
  site_id
FROM public.staff_app_welcome saw
JOIN auth.users u ON saw.user_id = u.id
WHERE u.email = 'ben.howard@stoke.nhs.uk';
