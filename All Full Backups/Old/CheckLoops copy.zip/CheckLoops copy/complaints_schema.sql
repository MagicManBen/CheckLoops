-- Complaints Management Schema for CheckLoop
-- Run this SQL in your Supabase SQL Editor
-- Updated to match existing CheckLoop database structure (bigint site_id)

-- Create complaints table
CREATE TABLE IF NOT EXISTS complaints (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    site_id BIGINT NOT NULL,
    datetime TIMESTAMPTZ NOT NULL,
    patient_initials VARCHAR(10) NOT NULL,
    category VARCHAR(100) NOT NULL,
    original_complaint TEXT,
    response TEXT,
    lessons_learned TEXT,
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'investigating', 'resolved', 'closed')),
    priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    share_with_team BOOLEAN DEFAULT false,
    original_document_url TEXT,
    response_document_url TEXT,
    ai_extracted BOOLEAN DEFAULT false,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_complaints_site_id ON complaints(site_id);
CREATE INDEX IF NOT EXISTS idx_complaints_datetime ON complaints(datetime);
CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_complaints_category ON complaints(category);
CREATE INDEX IF NOT EXISTS idx_complaints_created_at ON complaints(created_at);

-- Create complaint categories lookup table (optional - for consistency)
CREATE TABLE IF NOT EXISTS complaint_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    site_id BIGINT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(site_id, name)
);

-- Insert default complaint categories
INSERT INTO complaint_categories (site_id, name, description)
SELECT
    0 as site_id, -- Use 0 as default site_id for shared categories
    category_name,
    category_description
FROM (
    SELECT
        unnest(ARRAY[
            'Clinical Care',
            'Communication', 
            'Access & Appointments',
            'Staff Attitude',
            'Facilities',
            'Administration',
            'Privacy & Confidentiality',
            'Prescription Issues',
            'Waiting Times',
            'Other'
        ]) as category_name,
        unnest(ARRAY[
            'Issues related to medical treatment and clinical decisions',
            'Problems with information sharing and communication',
            'Difficulties booking appointments or accessing services',
            'Concerns about staff behavior and professionalism',
            'Issues with practice premises and equipment',
            'Administrative errors and process problems',
            'Breaches of patient confidentiality',
            'Problems with prescriptions and medications',
            'Excessive waiting times for appointments or services',
            'Other complaints not covered by specific categories'
        ]) as category_description
) categories
ON CONFLICT (site_id, name) DO NOTHING;

-- Create complaint attachments table (for multiple file uploads per complaint)
CREATE TABLE IF NOT EXISTS complaint_attachments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_type VARCHAR(100),
    file_size INTEGER,
    attachment_type VARCHAR(50) CHECK (attachment_type IN ('original', 'response', 'evidence', 'other')),
    uploaded_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index for attachments
CREATE INDEX IF NOT EXISTS idx_complaint_attachments_complaint_id ON complaint_attachments(complaint_id);

-- Create complaint notes/comments table (for tracking updates and communications)
CREATE TABLE IF NOT EXISTS complaint_notes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    note_text TEXT NOT NULL,
    note_type VARCHAR(50) DEFAULT 'update' CHECK (note_type IN ('update', 'internal', 'patient_contact', 'resolution')),
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index for notes
CREATE INDEX IF NOT EXISTS idx_complaint_notes_complaint_id ON complaint_notes(complaint_id);
CREATE INDEX IF NOT EXISTS idx_complaint_notes_created_at ON complaint_notes(created_at);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to complaints table
CREATE TRIGGER update_complaints_updated_at 
    BEFORE UPDATE ON complaints 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Create trigger to set resolved_at when status changes to resolved/closed
CREATE OR REPLACE FUNCTION set_resolved_at()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status IN ('resolved', 'closed') AND OLD.status NOT IN ('resolved', 'closed') THEN
        NEW.resolved_at = NOW();
    ELSIF NEW.status NOT IN ('resolved', 'closed') THEN
        NEW.resolved_at = NULL;
    END IF;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply resolved_at trigger
CREATE TRIGGER set_complaints_resolved_at 
    BEFORE UPDATE ON complaints 
    FOR EACH ROW 
    EXECUTE FUNCTION set_resolved_at();

-- Enable Row Level Security (RLS)
ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaint_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaint_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaint_notes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for complaints
CREATE POLICY "Users can view complaints for their site" ON complaints
    FOR SELECT USING (
        site_id IN (
            SELECT site_id FROM profiles WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert complaints for their site" ON complaints
    FOR INSERT WITH CHECK (
        site_id IN (
            SELECT site_id FROM profiles WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update complaints for their site" ON complaints
    FOR UPDATE USING (
        site_id IN (
            SELECT site_id FROM profiles WHERE user_id = auth.uid()
        )
    );

-- Create RLS policies for complaint_categories  
CREATE POLICY "Users can view categories" ON complaint_categories
    FOR SELECT USING (
        site_id = 0 OR site_id IN (
            SELECT site_id FROM profiles WHERE user_id = auth.uid()
        )
    );

-- Create RLS policies for complaint_attachments
CREATE POLICY "Users can view attachments for complaints in their site" ON complaint_attachments
    FOR SELECT USING (
        complaint_id IN (
            SELECT id FROM complaints WHERE site_id IN (
                SELECT site_id FROM profiles WHERE user_id = auth.uid()
            )
        )
    );

CREATE POLICY "Users can insert attachments for complaints in their site" ON complaint_attachments
    FOR INSERT WITH CHECK (
        complaint_id IN (
            SELECT id FROM complaints WHERE site_id IN (
                SELECT site_id FROM profiles WHERE user_id = auth.uid()
            )
        )
    );

-- Create RLS policies for complaint_notes
CREATE POLICY "Users can view notes for complaints in their site" ON complaint_notes
    FOR SELECT USING (
        complaint_id IN (
            SELECT id FROM complaints WHERE site_id IN (
                SELECT site_id FROM profiles WHERE user_id = auth.uid()
            )
        )
    );

CREATE POLICY "Users can insert notes for complaints in their site" ON complaint_notes
    FOR INSERT WITH CHECK (
        complaint_id IN (
            SELECT id FROM complaints WHERE site_id IN (
                SELECT site_id FROM profiles WHERE user_id = auth.uid()
            )
        )
    );

-- Create storage bucket for complaint documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'complaint-documents',
    'complaint-documents',
    true,
    10485760, -- 10MB limit
    ARRAY['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'image/jpeg', 'image/png', 'image/gif']
) ON CONFLICT (id) DO NOTHING;

-- Create storage policies for complaint documents
CREATE POLICY "Users can upload complaint documents for their site" ON storage.objects
    FOR INSERT WITH CHECK (
        bucket_id = 'complaint-documents' AND
        auth.uid() IN (
            SELECT user_id FROM profiles WHERE site_id IS NOT NULL
        )
    );

CREATE POLICY "Users can view complaint documents for their site" ON storage.objects
    FOR SELECT USING (
        bucket_id = 'complaint-documents' AND
        auth.uid() IN (
            SELECT user_id FROM profiles WHERE site_id IS NOT NULL
        )
    );

-- Create useful views for reporting
CREATE OR REPLACE VIEW complaint_summary AS
SELECT 
    c.*,
    cc.description as category_description,
    p.full_name as created_by_name,
    CASE 
        WHEN c.resolved_at IS NOT NULL THEN 
            EXTRACT(DAY FROM c.resolved_at - c.datetime)
        WHEN c.status NOT IN ('resolved', 'closed') THEN 
            EXTRACT(DAY FROM NOW() - c.datetime)
        ELSE NULL 
    END as days_to_resolve,
    COUNT(ca.id) as attachment_count,
    COUNT(cn.id) as note_count
FROM complaints c
LEFT JOIN complaint_categories cc ON c.category = cc.name AND c.site_id = cc.site_id
LEFT JOIN profiles p ON c.created_by = p.user_id
LEFT JOIN complaint_attachments ca ON c.id = ca.complaint_id
LEFT JOIN complaint_notes cn ON c.id = cn.complaint_id
GROUP BY c.id, cc.description, p.full_name;

-- Grant necessary permissions
GRANT ALL ON complaints TO authenticated;
GRANT ALL ON complaint_categories TO authenticated;
GRANT ALL ON complaint_attachments TO authenticated;
GRANT ALL ON complaint_notes TO authenticated;
GRANT SELECT ON complaint_summary TO authenticated;

-- Comments for documentation
COMMENT ON TABLE complaints IS 'Main table storing patient complaints and their resolution details';
COMMENT ON TABLE complaint_categories IS 'Lookup table for standardized complaint categories';
COMMENT ON TABLE complaint_attachments IS 'File attachments related to complaints (documents, emails, etc.)';
COMMENT ON TABLE complaint_notes IS 'Timeline of notes and updates for each complaint';
COMMENT ON VIEW complaint_summary IS 'Comprehensive view of complaints with additional calculated fields';
