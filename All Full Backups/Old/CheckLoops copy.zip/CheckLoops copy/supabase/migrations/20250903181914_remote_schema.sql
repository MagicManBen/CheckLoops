

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE SCHEMA IF NOT EXISTS "admin";


ALTER SCHEMA "admin" OWNER TO "postgres";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "public";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "admin"."full_export"("include_data" boolean DEFAULT true, "max_rows_per_table" integer DEFAULT NULL::integer) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
declare
  result          jsonb := '{}'::jsonb;
  tmp             jsonb;
  tbl_data        jsonb;
  r record;
  row_limit_sql   text;
begin
  -- ---------- Basic DB info ----------
  result := result || jsonb_build_object(
    'database', jsonb_build_object(
      'current_database', current_database(),
      'version', version()
    ),
    'schemas', (
      select jsonb_agg(jsonb_build_object(
        'schema_name', n.nspname,
        'owner', pg_get_userbyid(n.nspowner)
      ) order by n.nspname)
      from pg_namespace n
      where n.nspname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Tables ----------
  result := result || jsonb_build_object(
    'tables', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', t.table_schema,
          'table',  t.table_name,
          'table_type', t.table_type,
          'owner', pg_get_userbyid(c.relowner)
        )
        order by t.table_schema, t.table_name
      )
      from information_schema.tables t
      join pg_class c
        on c.relname = t.table_name
       and c.relkind in ('r','p','f','v','m')  -- base, partitioned, foreign, view, mview
      join pg_namespace ns
        on ns.oid = c.relnamespace
       and ns.nspname = t.table_schema
      where t.table_schema not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Columns ----------
  result := result || jsonb_build_object(
    'columns', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', c.table_schema,
          'table',  c.table_name,
          'column', c.column_name,
          'ordinal_position', c.ordinal_position,
          'data_type', c.data_type,
          'is_nullable', c.is_nullable,
          'default', c.column_default,
          'udt_name', c.udt_name,
          'character_maximum_length', c.character_maximum_length,
          'numeric_precision', c.numeric_precision,
          'numeric_scale', c.numeric_scale
        )
        order by c.table_schema, c.table_name, c.ordinal_position
      )
      from information_schema.columns c
      where c.table_schema not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Constraints ----------
  result := result || jsonb_build_object(
    'constraints', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'table',  cls.relname,
          'constraint', con.conname,
          'type', con.contype,
          'definition', pg_get_constraintdef(con.oid, true)
        )
        order by n.nspname, cls.relname, con.conname
      )
      from pg_constraint con
      join pg_class cls on cls.oid = con.conrelid
      join pg_namespace n on n.oid = cls.relnamespace
      where n.nspname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Indexes ----------
  result := result || jsonb_build_object(
    'indexes', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', schemaname,
          'table',  tablename,
          'index',  indexname,
          'definition', indexdef
        )
        order by schemaname, tablename, indexname
      )
      from pg_indexes
      where schemaname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Triggers ----------
  result := result || jsonb_build_object(
    'triggers', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'table',  c.relname,
          'trigger', t.tgname,
          'definition', pg_get_triggerdef(t.oid, true),
          'enabled', t.tgenabled
        )
        order by n.nspname, c.relname, t.tgname
      )
      from pg_trigger t
      join pg_class c on c.oid = t.tgrelid
      join pg_namespace n on n.oid = c.relnamespace
      where not t.tgisinternal
        and n.nspname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Views & Materialized Views ----------
  result := result || jsonb_build_object(
    'views', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', table_schema,
          'view', table_name,
          'definition', pg_get_viewdef(format('%I.%I', table_schema, table_name)::regclass, true),
          'check_option', check_option,
          'is_updatable', is_updatable
        )
        order by table_schema, table_name
      )
      from information_schema.views
      where table_schema not in ('pg_catalog','information_schema')
    ),
    'materialized_views', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'mview',  c.relname,
          'definition', pg_get_viewdef(c.oid, true)
        )
        order by n.nspname, c.relname
      )
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      where c.relkind = 'm'
        and n.nspname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Functions ----------
  result := result || jsonb_build_object(
    'functions', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'function', p.proname,
          'arguments', pg_get_function_identity_arguments(p.oid),
          'returns', pg_get_function_result(p.oid),
          'volatility', p.provolatile,
          'leakproof', p.proleakproof,
          'security_definer', p.prosecdef,
          'owner', pg_get_userbyid(p.proowner),
          'source', pg_get_functiondef(p.oid)
        )
        order by n.nspname, p.proname
      )
      from pg_proc p
      join pg_namespace n on n.oid = p.pronamespace
      where n.nspname not in ('pg_catalog','information_schema','pg_toast')
    )
  );

  -- ---------- Sequences ----------
  result := result || jsonb_build_object(
    'sequences', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', sequence_schema,
          'sequence', sequence_name,
          'data_type', data_type,
          'start_value', start_value,
          'minimum_value', minimum_value,
          'maximum_value', maximum_value,
          'increment', increment,
          'cycle_option', cycle_option
        )
        order by sequence_schema, sequence_name
      )
      from information_schema.sequences
      where sequence_schema not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Extensions ----------
  result := result || jsonb_build_object(
    'extensions', (
      select jsonb_agg(
        jsonb_build_object(
          'name', e.extname,
          'version', e.extversion,
          'schema', n.nspname
        )
        order by e.extname
      )
      from pg_extension e
      join pg_namespace n on n.oid = e.extnamespace
    )
  );

  -- ---------- Roles & Memberships ----------
  result := result || jsonb_build_object(
    'roles', (
      select jsonb_agg(
        jsonb_build_object(
          'rolname', r.rolname,
          'superuser', r.rolsuper,
          'inherit', r.rolinherit,
          'createrole', r.rolcreaterole,
          'createdb', r.rolcreatedb,
          'can_login', r.rolcanlogin,
          'replication', r.rolreplication,
          'bypassrls', r.rolbypassrls
        )
        order by r.rolname
      )
      from pg_roles r
    ),
    'role_memberships', (
      select jsonb_agg(
        jsonb_build_object(
          'role', r.rolname,
          'member', m.rolname,
          'grantor', g.rolname,
          'admin_option', am.admin_option
        )
        order by r.rolname, m.rolname
      )
      from pg_auth_members am
      join pg_roles r on r.oid = am.roleid
      join pg_roles m on m.oid = am.member
      join pg_roles g on g.oid = am.grantor
    )
  );

  -- ---------- Grants (tables, columns, routines, schemas, usage) ----------
  result := result || jsonb_build_object(
    'table_privileges', (
      select jsonb_agg(
        jsonb_build_object(
          'grantee', grantee, 'grantor', grantor,
          'schema', table_schema, 'table', table_name,
          'privilege_type', privilege_type, 'is_grantable', is_grantable
        )
        order by table_schema, table_name, grantee, privilege_type
      )
      from information_schema.table_privileges
      where table_schema not in ('pg_catalog','information_schema')
    ),
    'column_privileges', (
      select jsonb_agg(
        jsonb_build_object(
          'grantee', grantee, 'grantor', grantor,
          'schema', table_schema, 'table', table_name, 'column', column_name,
          'privilege_type', privilege_type, 'is_grantable', is_grantable
        )
        order by table_schema, table_name, column_name, grantee, privilege_type
      )
      from information_schema.column_privileges
      where table_schema not in ('pg_catalog','information_schema')
    ),
    'routine_privileges', (
      select jsonb_agg(
        jsonb_build_object(
          'grantee', grantee, 'grantor', grantor,
          'schema', specific_schema, 'routine', routine_name,
          'privilege_type', privilege_type, 'is_grantable', is_grantable
        )
        order by specific_schema, routine_name, grantee, privilege_type
      )
      from information_schema.routine_privileges
      where specific_schema not in ('pg_catalog','information_schema')
    ),
    'schema_privileges', (
      select jsonb_agg(
        jsonb_build_object(
          'grantee', grantee, 'grantor', grantor,
          'schema', schema_name,
          'privilege_type', privilege_type, 'is_grantable', is_grantable
        )
        order by schema_name, grantee, privilege_type
      )
      from information_schema.schema_privileges
      where schema_name not in ('pg_catalog','information_schema')
    ),
    'usage_privileges', (
      select jsonb_agg(
        jsonb_build_object(
          'grantee', grantee, 'grantor', grantor,
          'object_catalog', object_catalog,
          'object_schema', object_schema,
          'object_name', object_name,
          'object_type', object_type,
          'privilege_type', privilege_type, 'is_grantable', is_grantable
        )
        order by object_schema, object_name, grantee, privilege_type
      )
      from information_schema.usage_privileges
      where object_schema not in ('pg_catalog','information_schema')
    ),
    'default_privileges', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'owner', pg_get_userbyid(d.defaclrole),
          'objtype', d.defaclobjtype,
          'acl', d.defaclacl
        )
        order by n.nspname, d.defaclobjtype
      ), '[]'::jsonb)
      from pg_default_acl d
      left join pg_namespace n on n.oid = d.defaclnamespace
    )
  );

  -- ---------- Row Level Security ----------
  result := result || jsonb_build_object(
    'rls_tables', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'table', c.relname,
          'rls_enabled', c.relrowsecurity,
          'rls_forced', c.relforcerowsecurity
        )
        order by n.nspname, c.relname
      )
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      where c.relkind in ('r','p') -- tables, partitioned tables
        and n.nspname not in ('pg_catalog','information_schema')
    ),
    'rls_policies', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'schema', pol.schemaname,
          'table',  pol.tablename,
          'policy', pol.policyname,
          'cmd',    pol.cmd,
          'permissive', pol.permissive,
          'roles',  pol.roles,
          'qual',   pol.qual,
          'with_check', pol.with_check
        )
        order by pol.schemaname, pol.tablename, pol.policyname
      ), '[]'::jsonb)
      from pg_policies pol
    )
  );

  -- ---------- Publications (logical replication) ----------
  result := result || jsonb_build_object(
    'publications', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'name', p.pubname,
          'owner', pg_get_userbyid(p.pubowner),
          'all_tables', p.puballtables,
          'publish_insert', p.pubinsert,
          'publish_update', p.pubupdate,
          'publish_delete', p.pubdelete,
          'publish_truncate', p.pubtruncate
        )
        order by p.pubname
      ), '[]'::jsonb)
      from pg_publication p
    )
  );

  -- ---------- Foreign Data ----------
  result := result || jsonb_build_object(
    'foreign_servers', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'server_name', s.srvname,
          'fdw',        fdw.fdwname,
          'options',    s.srvoptions
        )
        order by s.srvname
      ), '[]'::jsonb)
      from pg_foreign_server s
      join pg_foreign_data_wrapper fdw on fdw.oid = s.srvfdw
    ),
    'user_mappings', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'server_name', s.srvname,
          'user',        coalesce(u.rolname, 'public'),
          'options',     um.umoptions
        )
        order by s.srvname, u.rolname
      ), '[]'::jsonb)
      from pg_user_mappings um
      join pg_foreign_server s on s.oid = um.srvid
      left join pg_roles u on u.oid = um.umuser
    ),
    'foreign_tables', (
      select coalesce(jsonb_agg(
        jsonb_build_object(
          'schema', n.nspname,
          'table',  c.relname,
          'server', s.srvname,
          'options', ft.ftoptions
        )
        order by n.nspname, c.relname
      ), '[]'::jsonb)
      from pg_foreign_table ft
      join pg_class c on c.oid = ft.ftrelid
      join pg_namespace n on n.oid = c.relnamespace
      join pg_foreign_server s on s.oid = ft.ftserver
      where n.nspname not in ('pg_catalog','information_schema')
    )
  );

  -- ---------- Selected DB settings (useful subset) ----------
  result := result || jsonb_build_object(
    'settings', (
      select jsonb_object_agg(name, setting)
      from pg_settings
      where name in (
        'server_version','TimeZone','search_path','max_connections',
        'log_statement','log_min_error_statement','shared_buffers'
      )
    )
  );

  -- ---------- Table data (optional, may be huge) ----------
  if include_data then
    result := result || jsonb_build_object('data', '{}'::jsonb);

    row_limit_sql := case
      when max_rows_per_table is null then ''
      else format(' limit %s', max_rows_per_table)
    end;

    for r in
      select schemaname, tablename
      from pg_catalog.pg_tables
      where schemaname not in ('pg_catalog','information_schema')
      order by schemaname, tablename
    loop
      execute format(
        'select coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb)
           from (select * from %I.%I%s) t',
        r.schemaname, r.tablename, row_limit_sql
      )
      into tbl_data;

      result := jsonb_set(
        result,
        array['data', r.schemaname || '.' || r.tablename],
        coalesce(tbl_data, '[]'::jsonb),
        true
      );
    end loop;
  end if;

  return result;
end;
$$;


ALTER FUNCTION "admin"."full_export"("include_data" boolean, "max_rows_per_table" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "admin"."quick_export"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
declare
  result    jsonb := '{}'::jsonb;
  tbl_data  jsonb;
  r         record;
begin
  -- Tables & Columns
  result := result || jsonb_build_object(
    'tables', (
      select jsonb_agg(
        jsonb_build_object(
          'schema', t.table_schema,
          'table',  t.table_name,
          'columns', (
            select jsonb_agg(
              jsonb_build_object(
                'column', c.column_name,
                'type',   c.data_type,
                'nullable', c.is_nullable,
                'default',  c.column_default
              )
              order by c.ordinal_position
            )
            from information_schema.columns c
            where c.table_schema = t.table_schema
              and c.table_name = t.table_name
          )
        )
        order by t.table_schema, t.table_name
      )
      from information_schema.tables t
      where t.table_schema not in ('pg_catalog','information_schema')
    )
  );

  -- 3 sample rows from each table
  result := result || jsonb_build_object('data', '{}'::jsonb);

  for r in
    select schemaname, tablename
    from pg_catalog.pg_tables
    where schemaname not in ('pg_catalog','information_schema')
    order by schemaname, tablename
  loop
    execute format(
      'select coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb)
         from (select * from %I.%I limit 3) t',
      r.schemaname, r.tablename
    )
    into tbl_data;

    result := jsonb_set(
      result,
      array['data', r.schemaname || '.' || r.tablename],
      coalesce(tbl_data, '[]'::jsonb),
      true
    );
  end loop;

  -- Top-line security summary
  result := result || jsonb_build_object(
    'security', jsonb_build_object(
      'roles', (
        select jsonb_agg(rolname order by rolname)
        from pg_roles
      ),
      'rls_tables', (
        select jsonb_agg(
          jsonb_build_object(
            'schema', n.nspname,
            'table', c.relname,
            'rls_enabled', c.relrowsecurity
          )
          order by n.nspname, c.relname
        )
        from pg_class c
        join pg_namespace n on n.oid = c.relnamespace
        where c.relkind = 'r'
          and n.nspname not in ('pg_catalog','information_schema')
      )
    )
  );

  return result;
end;
$$;


ALTER FUNCTION "admin"."quick_export"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."accept_invite"("_token" "uuid") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  inv record;
  uid uuid := auth.uid();
  sid bigint;
  my_email text;
begin
  if uid is null then
    raise exception 'Not signed in';
  end if;

  select email into my_email from auth.users where id = uid;
  if my_email is null then
    raise exception 'User has no email';
  end if;

  select *
  into inv
  from public.site_invites
  where token = _token
    and status in ('pending','approved')
    and (expires_at is null or expires_at > now());

  if not found then
    raise exception 'Invalid or expired invite';
  end if;

  if lower(inv.email) <> lower(my_email) then
    raise exception 'Invite email mismatch';
  end if;

  sid := inv.site_id;

  -- Link or move the user to this site with invited role
  insert into public.profiles(user_id, site_id, role)
  values (uid, sid, coalesce(inv.role, 'staff'))
  on conflict (user_id)
    do update set site_id = excluded.site_id, role = excluded.role;

  -- Apply per-user page overrides from invite (optional)
  if inv.allowed_pages is not null then
    insert into public.user_permissions(user_id, site_id, allowed_pages)
    values (uid, sid, inv.allowed_pages)
    on conflict (user_id, site_id)
      do update set allowed_pages = excluded.allowed_pages;
  end if;

  -- Mark invite consumed/approved
  update public.site_invites
    set status = 'approved'
  where id = inv.id;

  return sid;
end;
$$;


ALTER FUNCTION "public"."accept_invite"("_token" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_set_item_check"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval DEFAULT '3 days'::interval, "p_required" boolean DEFAULT true, "p_active" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_item_id bigint;
  v_type_id bigint;
begin
  perform public.assert_admin(p_site_id);

  select id into v_item_id
  from public.items
  where site_id = p_site_id and item_id = p_item_code;
  if v_item_id is null then
    raise exception 'Item not found for site % and code %', p_site_id, p_item_code;
  end if;

  select id into v_type_id
  from public.check_types
  where site_id = p_site_id and name = p_check_type_name;
  if v_type_id is null then
    raise exception 'Check type not found for site % and name %', p_site_id, p_check_type_name;
  end if;

  insert into public.item_allowed_types(site_id, item_id, check_type_id, frequency, warn_before, required, active)
  values (p_site_id, v_item_id, v_type_id, p_frequency, p_warn_before, p_required, p_active)
  on conflict (site_id, item_id, check_type_id) do update
    set frequency   = excluded.frequency,
        warn_before = excluded.warn_before,
        required    = excluded.required,
        active      = excluded.active;
end
$$;


ALTER FUNCTION "public"."admin_set_item_check"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_set_item_check_team"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval DEFAULT '3 days'::interval, "p_required" boolean DEFAULT true, "p_active" boolean DEFAULT true, "p_responsible_team_id" bigint DEFAULT NULL::bigint) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_item_pk bigint;
  v_type_id bigint;
begin
  select id into v_item_pk from public.items where site_id = p_site_id and item_id = trim(p_item_code);
  if v_item_pk is null then raise exception 'Item not found for site % and code %', p_site_id, p_item_code; end if;

  select id into v_type_id from public.check_types where site_id = p_site_id and name = trim(p_check_type_name);
  if v_type_id is null then raise exception 'Check type not found for site % and name %', p_site_id, p_check_type_name; end if;

  insert into public.item_allowed_types(site_id,item_id,check_type_id,frequency,warn_before,required,active,responsible_team_id)
  values (p_site_id, v_item_pk, v_type_id, p_frequency, p_warn_before, p_required, p_active, p_responsible_team_id)
  on conflict (site_id, item_id, check_type_id) do update
    set frequency = excluded.frequency,
        warn_before = excluded.warn_before,
        required = excluded.required,
        active = excluded.active,
        responsible_team_id = excluded.responsible_team_id;
end $$;


ALTER FUNCTION "public"."admin_set_item_check_team"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean, "p_responsible_team_id" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_upsert_item"("p_site_id" bigint, "p_item_id" "text", "p_item_name" "text", "p_room_name" "text", "p_category" "text", "p_default_check_type_name" "text", "p_comments" "text" DEFAULT NULL::"text") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_room_id  bigint;
  v_type_id  bigint;
  v_item_pk  bigint;
begin
  -- only owners/admins for this site
  perform public.assert_admin(p_site_id);

  -- resolve/create room
  if p_room_name is not null and length(trim(p_room_name)) > 0 then
    select id into v_room_id
    from public.rooms
    where site_id = p_site_id and name = trim(p_room_name);

    if v_room_id is null then
      insert into public.rooms(site_id, name)
      values (p_site_id, trim(p_room_name))
      on conflict (site_id, name) do update set name = excluded.name
      returning id into v_room_id;
    end if;
  end if;

  -- resolve/create default check type
  if p_default_check_type_name is not null and length(trim(p_default_check_type_name)) > 0 then
    select id into v_type_id
    from public.check_types
    where site_id = p_site_id and name = trim(p_default_check_type_name);

    if v_type_id is null then
      insert into public.check_types(site_id, name, category)
      values (p_site_id, trim(p_default_check_type_name), coalesce(p_category,'general'))
      on conflict (site_id, name) do update set name = excluded.name
      returning id into v_type_id;
    end if;
  end if;

  -- upsert item
  insert into public.items(
    site_id, item_id, item_name, category, comments, room_id, default_check_type_id
  ) values (
    p_site_id, trim(p_item_id), p_item_name, coalesce(p_category,'general'), p_comments, v_room_id, v_type_id
  )
  on conflict (site_id, item_id) do update set
    item_name = excluded.item_name,
    category  = excluded.category,
    comments  = excluded.comments,
    room_id   = excluded.room_id,
    default_check_type_id = excluded.default_check_type_id
  returning id into v_item_pk;

  return v_item_pk;
end
$$;


ALTER FUNCTION "public"."admin_upsert_item"("p_site_id" bigint, "p_item_id" "text", "p_item_name" "text", "p_room_name" "text", "p_category" "text", "p_default_check_type_name" "text", "p_comments" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."app_bootstrap"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'extensions'
    AS $$
declare
  _uid uuid := auth.uid();
  _site_id bigint;
  _j jsonb := '{}'::jsonb;
  _tmp jsonb;
begin
  -- Current user’s profile (must exist to get site_id)
  select p.site_id
  into _site_id
  from profiles p
  where p.user_id = _uid;

  -- Always include caller + profile (profile may be null)
  _j := jsonb_build_object(
    'user', jsonb_build_object('id', _uid),
    'profile', (select to_jsonb(p) from profiles p where p.user_id = _uid)
  );

  -- If no profile, return a minimal payload so the client can prompt for site assignment
  if _site_id is null then
    return _j || jsonb_build_object(
      'site_id', null,
      'rooms', '[]'::jsonb,
      'check_types', '[]'::jsonb,
      'items', '[]'::jsonb,
      'items_admin', '[]'::jsonb,
      'item_allowed_types', '[]'::jsonb,
      'kiosk_users', '[]'::jsonb,
      'submissions', '[]'::jsonb,
      'submission_rows', '[]'::jsonb
    );
  end if;

  -- Base tables (filtered to site)
  select coalesce(jsonb_agg(to_jsonb(r) order by r.name), '[]'::jsonb)
  into _tmp from rooms r where r.site_id = _site_id;
  _j := _j || jsonb_build_object('rooms', _tmp);

  select coalesce(jsonb_agg(to_jsonb(ct) order by ct.name), '[]'::jsonb)
  into _tmp from check_types ct where ct.site_id = _site_id;
  _j := _j || jsonb_build_object('check_types', _tmp);

  select coalesce(jsonb_agg(to_jsonb(i) order by i.item_name), '[]'::jsonb)
  into _tmp from items i where i.site_id = _site_id;
  _j := _j || jsonb_build_object('items', _tmp);

  select coalesce(jsonb_agg(to_jsonb(iat) order by iat.item_id, iat.check_type_id), '[]'::jsonb)
  into _tmp from item_allowed_types iat where iat.site_id = _site_id;
  _j := _j || jsonb_build_object('item_allowed_types', _tmp);

  select coalesce(jsonb_agg(to_jsonb(ku) order by ku.full_name), '[]'::jsonb)
  into _tmp from kiosk_users ku where ku.site_id = _site_id;
  _j := _j || jsonb_build_object('kiosk_users', _tmp);

  -- Recent submissions + their rows
  with subs as (
    select s.*
    from submissions s
    where s.site_id = _site_id
    order by s.submitted_at desc
    limit 200
  )
  select coalesce(jsonb_agg(to_jsonb(s) order by s.submitted_at desc), '[]'::jsonb)
  into _tmp from subs s;
  _j := _j || jsonb_build_object('submissions', _tmp);

  with subs as (
    select s.id
    from submissions s
    where s.site_id = _site_id
    order by s.submitted_at desc
    limit 200
  )
  select coalesce(jsonb_agg(to_jsonb(sr) order by sr.submission_id, sr.id), '[]'::jsonb)
  into _tmp
  from submission_rows sr
  join subs on subs.id = sr.submission_id
  where sr.site_id = _site_id;
  _j := _j || jsonb_build_object('submission_rows', _tmp);

  -- Inline “admin view” (items + room name + default type name) without depending on a DB view
  with x as (
    select
      i.id,
      i.site_id,
      i.item_id,
      i.item_name,
      i.category,
      i.active,
      i.room_id,
      coalesce(r.name, i.room) as room_name,
      i.default_check_type_id,
      (select ct.name from check_types ct where ct.id = i.default_check_type_id) as default_check_type_name,
      i.comments
    from items i
    left join rooms r on r.id = i.room_id
    where i.site_id = _site_id
  )
  select coalesce(jsonb_agg(to_jsonb(x) order by x.item_name), '[]'::jsonb)
  into _tmp from x;
  _j := _j || jsonb_build_object('items_admin', _tmp);

  -- Optional bundles (only if the objects exist)
  if to_regclass('public.v_items_admin') is not null then
    select coalesce(jsonb_agg(to_jsonb(v) order by v.item_name), '[]'::jsonb)
    into _tmp from v_items_admin v where v.site_id = _site_id;
    _j := _j || jsonb_build_object('v_items_admin', _tmp);
  end if;

  if to_regclass('public.v_item_check_status') is not null then
    select coalesce(jsonb_agg(to_jsonb(v)), '[]'::jsonb)
    into _tmp from v_item_check_status v where v.site_id = _site_id;
    _j := _j || jsonb_build_object('v_item_check_status', _tmp);
  end if;

  if to_regclass('public.v_item_check_summary') is not null then
    select coalesce(jsonb_agg(to_jsonb(v)), '[]'::jsonb)
    into _tmp from v_item_check_summary v where v.site_id = _site_id;
    _j := _j || jsonb_build_object('v_item_check_summary', _tmp);
  end if;

  if to_regclass('public.v_submission_detail') is not null then
    select coalesce(jsonb_agg(to_jsonb(v) order by v.submitted_at desc), '[]'::jsonb)
    into _tmp from v_submission_detail v where v.site_id = _site_id limit 500;
    _j := _j || jsonb_build_object('v_submission_detail', _tmp);
  end if;

  -- Teams (optional)
  if to_regclass('public.teams') is not null then
    select coalesce(jsonb_agg(to_jsonb(t) order by t.name), '[]'::jsonb)
    into _tmp from teams t where t.site_id = _site_id;
    _j := _j || jsonb_build_object('teams', _tmp);
  end if;

  if to_regclass('public.team_members') is not null then
    select coalesce(jsonb_agg(to_jsonb(tm) order by tm.team_id, tm.user_id), '[]'::jsonb)
    into _tmp from team_members tm where tm.site_id = _site_id;
    _j := _j || jsonb_build_object('team_members', _tmp);
  end if;

  if to_regclass('public.check_type_teams') is not null then
    select coalesce(jsonb_agg(to_jsonb(ctt) order by ctt.check_type_id, ctt.team_id), '[]'::jsonb)
    into _tmp from check_type_teams ctt where ctt.site_id = _site_id;
    _j := _j || jsonb_build_object('check_type_teams', _tmp);
  end if;

  -- Final payload
  return _j || jsonb_build_object('site_id', _site_id);
end
$$;


ALTER FUNCTION "public"."app_bootstrap"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."assert_admin"("p_site_id" bigint) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_uid uuid;
begin
  -- 1) direct sub
  begin
    v_uid := nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
  exception when others then
    v_uid := null;
  end;

  -- 2) full claims JSON (e.g., set_config('request.jwt.claims', '{"sub":"..."}'))
  if v_uid is null then
    begin
      v_uid := (current_setting('request.jwt.claims', true)::jsonb->>'sub')::uuid;
    exception when others then
      v_uid := null;
    end;
  end if;

  -- 3) normal path (works in app)
  if v_uid is null then
    v_uid := auth.uid();
  end if;

  if v_uid is null then
    raise exception 'Permission denied: no user id in context';
  end if;

  if not exists (
    select 1
    from public.profiles
    where user_id = v_uid
      and site_id = p_site_id
      and role in ('owner','admin')
  ) then
    raise exception 'Permission denied: admin or owner required';
  end if;
end;
$$;


ALTER FUNCTION "public"."assert_admin"("p_site_id" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."auth_check_pin"("p_site_id" bigint, "p_pin" "text") RETURNS TABLE("id" bigint, "full_name" "text", "role" "text")
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select id, full_name, role
    from public.kiosk_users
   where site_id = p_site_id
     and active = true
     and pin_hash is not null
     and public.crypt(p_pin::text, pin_hash) = pin_hash
   order by id
   limit 1;
$$;


ALTER FUNCTION "public"."auth_check_pin"("p_site_id" bigint, "p_pin" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."auth_device_token"() RETURNS "text"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
    SELECT COALESCE(
        current_setting('request.headers', true)::jsonb->>'x-device-token', 
        ''
    );
$$;


ALTER FUNCTION "public"."auth_device_token"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."calendar_events"("p_site_id" bigint, "p_from" "date", "p_to" "date") RETURNS TABLE("schedule_id" bigint, "item_id" bigint, "check_type_id" bigint, "due_date" "date")
    LANGUAGE "sql"
    AS $$
with base as (
  select
    iat.id               as schedule_id,
    iat.item_id,
    iat.check_type_id,
    iat.frequency,
    iat.scheduled_day,
    coalesce(v.last_done_at::date, iat.created_at::date) as anchor
  from item_allowed_types iat
  left join v_last_submission v
    on v.item_id = iat.item_id and v.check_type_id = iat.check_type_id
  where iat.site_id = p_site_id and iat.active = true
),
start_dates as (
  select
    b.*,
    case
      -- if a weekday is chosen, start at the NEXT occurrence of that weekday
      when b.scheduled_day is not null then
        b.anchor
        + (
            case
              when (
                (case b.scheduled_day
                   when 'Sun' then 0 when 'Mon' then 1 when 'Tue' then 2
                   when 'Wed' then 3 when 'Thu' then 4 when 'Fri' then 5 when 'Sat' then 6
                 end
                 - extract(dow from b.anchor)::int + 7
                ) % 7
              ) = 0 then 7
              else (
                (case b.scheduled_day
                   when 'Sun' then 0 when 'Mon' then 1 when 'Tue' then 2
                   when 'Wed' then 3 when 'Thu' then 4 when 'Fri' then 5 when 'Sat' then 6
                 end
                 - extract(dow from b.anchor)::int + 7
                ) % 7
              )
            end
          ) * interval '1 day'
      -- otherwise: start one frequency AFTER the anchor
      else (b.anchor + b.frequency)
    end as start_ts
  from base b
)
select
  s.schedule_id, s.item_id, s.check_type_id,
  (gs)::date as due_date
from start_dates s
cross join lateral generate_series(s.start_ts, p_to::timestamp, s.frequency) gs
where gs::date between p_from and p_to
order by due_date, schedule_id;
$$;


ALTER FUNCTION "public"."calendar_events"("p_site_id" bigint, "p_from" "date", "p_to" "date") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_site_invite"("p_email" "text") RETURNS TABLE("site_id" bigint, "site_name" "text", "role" "text")
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select si.site_id, s.name as site_name, si.role
  from public.site_invites si
  join public.sites s on s.id = si.site_id
  where lower(si.email) = lower(p_email)
    and si.status in ('pending','approved')
  order by si.created_at desc
  limit 1;
$$;


ALTER FUNCTION "public"."check_site_invite"("p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."create_invite"("_email" "text", "_role" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  uid        uuid := auth.uid();
  sid        bigint;
  token_out  uuid := gen_random_uuid();
  norm_email text := lower(trim(_email));
  norm_role  text := case when lower(coalesce(_role,'')) in ('admin','staff') then lower(_role) else 'staff' end;
begin
  if uid is null then
    raise exception 'Not signed in';
  end if;

  select p.site_id into sid
  from public.profiles p
  where p.user_id = uid;

  if sid is null then
    raise exception 'No site linked for this user';
  end if;

  if not exists (
    select 1 from public.profiles p
    where p.user_id = uid and p.site_id = sid and p.role in ('owner','admin')
  ) then
    raise exception 'Only site owner/admin can invite';
  end if;

  insert into public.site_invites (site_id, email, role, token, status, expires_at)
  values (sid, norm_email, norm_role, token_out, 'pending', now() + interval '14 days')
  on conflict on constraint site_invites_site_email_unique
  do update
    set role       = excluded.role,
        status     = 'pending',
        token      = excluded.token,
        expires_at = excluded.expires_at
  returning token into token_out;

  return token_out;
end
$$;


ALTER FUNCTION "public"."create_invite"("_email" "text", "_role" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."create_invite"("_email" "text", "_role" "text", "_full_name" "text", "_site_id" bigint, "_invited_by" "uuid") RETURNS TABLE("id" bigint, "token" "uuid")
    LANGUAGE "plpgsql"
    AS $$
begin
  insert into site_invites (email, role, full_name, site_id, invited_by)
  values (_email, _role, _full_name, _site_id, _invited_by)
  returning site_invites.id, site_invites.token into id, token;
end;
$$;


ALTER FUNCTION "public"."create_invite"("_email" "text", "_role" "text", "_full_name" "text", "_site_id" bigint, "_invited_by" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."create_site_and_owner"("_site_name" "text", "_full_name" "text") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  sid bigint;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;

  -- prevent double-link
  if exists(select 1 from public.profiles where user_id = auth.uid()) then
    raise exception 'User already linked to a site';
  end if;

  insert into public.sites(name) values (_site_name) returning id into sid;

  insert into public.profiles(user_id, site_id, role, full_name)
  values (auth.uid(), sid, 'owner', coalesce(_full_name, ''));

  return sid;
end;
$$;


ALTER FUNCTION "public"."create_site_and_owner"("_site_name" "text", "_full_name" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."debug_jwt"() RETURNS TABLE("uid" "uuid", "sub" "text", "claims_sub" "text")
    LANGUAGE "sql"
    AS $$
select
  auth.uid(),
  current_setting('request.jwt.claim.sub', true),
  (current_setting('request.jwt.claims', true)::jsonb->>'sub')
$$;


ALTER FUNCTION "public"."debug_jwt"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_current_user_org_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
    SELECT org_id 
    FROM public.profiles 
    WHERE user_id = auth.uid()
    LIMIT 1;
$$;


ALTER FUNCTION "public"."get_current_user_org_id"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) RETURNS TABLE("due_at" timestamp with time zone, "item_id" bigint, "item_name" "text", "room_name" "text", "check_type_id" bigint, "check_type" "text", "status_at_due" "text")
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
with s as (
  select * from public.v_item_check_status where site_id = p_site_id
),
occ as (
  select s.*, gs as due_at
  from s
  join lateral generate_series(s.next_due_at, p_end, s.frequency) as gs on true
  where gs >= p_start
)
select
  due_at,
  item_id,
  item_name,
  room_name,
  check_type_id,
  check_type,
  case
    when now() >= due_at then 'overdue'         -- e.g. > 7 days for weekly
    when now() >= due_at - warn_before then 'due_soon'
    else 'scheduled'
  end as status_at_due
from occ
order by due_at, room_name, item_name, check_type;
$$;


ALTER FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_my_site_id"() RETURNS bigint
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT site_id FROM public.profiles WHERE user_id = auth.uid() LIMIT 1;
$$;


ALTER FUNCTION "public"."get_my_site_id"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    new.updated_at = now();
    return new;
end;
$$;


ALTER FUNCTION "public"."handle_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."insert_invite"("_site_id" bigint, "_email" "text", "_role" "text" DEFAULT 'member'::"text") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth'
    AS $$
declare
  new_id bigint;
begin
  insert into public.site_invites
         (site_id, email, role, invited_by)
  values (_site_id, lower(_email), _role, auth.uid())
  returning id into new_id;

  return new_id;
end;
$$;


ALTER FUNCTION "public"."insert_invite"("_site_id" bigint, "_email" "text", "_role" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member"("site_id_in" bigint) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  select exists (
    select 1 from profiles p
    where p.user_id = auth.uid() and p.site_id = site_id_in
  );
$$;


ALTER FUNCTION "public"."is_member"("site_id_in" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_site_admin"("site_id_in" bigint) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  select exists (
    select 1 from profiles p
    where p.user_id = auth.uid()
      and p.site_id = site_id_in
      and p.role = 'admin'
  );
$$;


ALTER FUNCTION "public"."is_site_admin"("site_id_in" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."items_sync_default_type_text"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if tg_op = 'INSERT' then
    if new.default_check_type_id is not null then
      select ct.name into new.default_check_type
      from public.check_types ct
      where ct.id = new.default_check_type_id;
    end if;

  elsif tg_op = 'UPDATE' then
    if new.default_check_type_id is distinct from old.default_check_type_id then
      if new.default_check_type_id is not null then
        select ct.name into new.default_check_type
        from public.check_types ct
        where ct.id = new.default_check_type_id;
      else
        -- keep previous value rather than nulling the text
        new.default_check_type := old.default_check_type;
      end if;
    end if;
  end if;

  return new;
end
$$;


ALTER FUNCTION "public"."items_sync_default_type_text"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."items_sync_room_text"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  -- If an id is provided/changed, set the text from rooms
  if new.room_id is not null then
    select r.name into new.room
    from rooms r
    where r.id = new.room_id;

  -- Else if text is provided/changed, try to find matching room id (same site)
  elsif new.room is not null and new.room <> '' then
    select r.id into new.room_id
    from rooms r
    where r.site_id = new.site_id
      and r.name = new.room;
    -- if no match, leave room_id null (text can still show)
  end if;

  return new;
end;
$$;


ALTER FUNCTION "public"."items_sync_room_text"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."kiosk_users_hash_pin"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  -- If pin is NULL or empty, clear hash + hmac
  if new.pin is null or length(trim(new.pin)) = 0 then
    new.pin_hash := null;
    new.pin_hmac := null;
  else
    -- Otherwise, generate the hash and HMAC
    new.pin_hash := crypt(new.pin, gen_salt('bf', 6));  -- bcrypt hash
    new.pin_hmac := encode(hmac(new.pin, 'your_secret_key', 'sha256'), 'hex');
  end if;
  return new;
end;
$$;


ALTER FUNCTION "public"."kiosk_users_hash_pin"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."kiosk_users_sync_team_name"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if new.team_id is null then
    new.team_name := null;
  else
    select name into new.team_name from public.teams where id = new.team_id;
  end if;
  return new;
end;
$$;


ALTER FUNCTION "public"."kiosk_users_sync_team_name"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_kiosk_user_pin"("p_user_id" bigint, "p_site_id" bigint, "p_pin" "text") RETURNS "void"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  update public.kiosk_users
     set pin_hash = public.crypt(p_pin::text, public.gen_salt('bf')),
         pin_hmac = encode(public.hmac(p_pin::text, ('pin:'||p_site_id)::text, 'sha256'), 'hex'),
         pin      = null  -- ensure plaintext is cleared if the column still exists
   where id = p_user_id
     and site_id = p_site_id;
$$;


ALTER FUNCTION "public"."set_kiosk_user_pin"("p_user_id" bigint, "p_site_id" bigint, "p_pin" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_pir_document_status"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF NEW.file_path IS NULL OR btrim(NEW.file_path) = '' THEN
    NEW.status := 'Not Attached';
  ELSE
    NEW.status := 'Ready';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_pir_document_status"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_user_id uuid := auth.uid();
  v_site_id bigint;
begin
  if v_user_id is null then
    raise exception 'Not signed in';
  end if;

  insert into sites(name, city)
  values (p_site_name, p_city)
  returning id into v_site_id;

  insert into profiles(user_id, site_id, role, full_name)
  values (v_user_id, v_site_id, 'admin', coalesce(p_full_name, ''));

  return v_site_id;
end;
$$;


ALTER FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE 
    current_user_site_id bigint;
BEGIN
    -- Get the site_id for the current authenticated user
    SELECT site_id INTO current_user_site_id 
    FROM public.profiles 
    WHERE auth_user_id = auth.uid();
    
    -- Check if the provided site_id matches the user's site_id
    RETURN check_site_id = current_user_site_id;
END;
$$;


ALTER FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."submission_rows_sync_check_type_text"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if new.check_type_id is null then
    return new;
  else
    select name into new.check_type from public.check_types where id = new.check_type_id;
  end if;
  return new;
end$$;


ALTER FUNCTION "public"."submission_rows_sync_check_type_text"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."submissions_sync_staff_name"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if new.staff_id is null then
    return new;
  end if;

  select full_name into new.staff_name
  from public.kiosk_users
  where id = new.staff_id;

  return new;
end$$;


ALTER FUNCTION "public"."submissions_sync_staff_name"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."teams_cascade_name_to_users"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  update public.kiosk_users
  set    team_name = new.name
  where  team_id = new.id;
  return new;
end;
$$;


ALTER FUNCTION "public"."teams_cascade_name_to_users"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_updated_at_column"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."check_events" (
    "id" bigint NOT NULL,
    "site_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "device_token" "text",
    CONSTRAINT "check_events_site_id_check" CHECK (("site_id" IS NOT NULL))
);


ALTER TABLE "public"."check_events" OWNER TO "postgres";


ALTER TABLE "public"."check_events" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."check_events_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."check_type_teams" (
    "site_id" bigint NOT NULL,
    "check_type_id" bigint NOT NULL,
    "team_id" bigint NOT NULL
);


ALTER TABLE "public"."check_type_teams" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."check_types" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "name" "text" NOT NULL,
    "category" "text" DEFAULT 'general'::"text" NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    CONSTRAINT "check_types_category_chk" CHECK (("category" = ANY (ARRAY['general'::"text", 'trolley'::"text", 'fridge'::"text", 'room'::"text", 'fire_safety'::"text"])))
);


ALTER TABLE "public"."check_types" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."check_types_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."check_types_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."check_types_id_seq" OWNED BY "public"."check_types"."id";



CREATE TABLE IF NOT EXISTS "public"."item_allowed_types" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "item_id" bigint NOT NULL,
    "check_type_id" bigint NOT NULL,
    "frequency" interval DEFAULT '00:00:00'::interval NOT NULL,
    "warn_before" interval DEFAULT '3 days'::interval NOT NULL,
    "required" boolean DEFAULT true NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "responsible_team_id" bigint,
    "scheduled_day" "text",
    CONSTRAINT "scheduled_day_chk" CHECK ((("scheduled_day" IS NULL) OR (("scheduled_day" = ANY (ARRAY['Sun'::"text", 'Mon'::"text", 'Tue'::"text", 'Wed'::"text", 'Thu'::"text", 'Fri'::"text", 'Sat'::"text"])) OR ("scheduled_day" ~ '^([1-9]|[12][0-9]|3[01])$'::"text"))))
);


ALTER TABLE "public"."item_allowed_types" OWNER TO "postgres";


COMMENT ON COLUMN "public"."item_allowed_types"."scheduled_day" IS 'For weekly schedules: three letter day (Sun,Mon,etc). For monthly schedules: day of month (1-31)';



CREATE SEQUENCE IF NOT EXISTS "public"."item_allowed_types_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."item_allowed_types_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."item_allowed_types_id_seq" OWNED BY "public"."item_allowed_types"."id";



CREATE TABLE IF NOT EXISTS "public"."items" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "item_id" "text" NOT NULL,
    "item_name" "text" NOT NULL,
    "room" "text" DEFAULT 'Unassigned'::"text" NOT NULL,
    "default_check_type" "text",
    "category" "text" DEFAULT 'general'::"text" NOT NULL,
    "comments" "text",
    "room_id" bigint,
    "default_check_type_id" bigint,
    "active" boolean DEFAULT true NOT NULL,
    CONSTRAINT "items_category_chk" CHECK (("category" = ANY (ARRAY['general'::"text", 'trolley'::"text", 'fridge'::"text", 'room'::"text", 'fire_safety'::"text"])))
);


ALTER TABLE "public"."items" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."items_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."items_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."items_id_seq" OWNED BY "public"."items"."id";



CREATE TABLE IF NOT EXISTS "public"."kiosk_roles" (
    "role" "text" NOT NULL
);


ALTER TABLE "public"."kiosk_roles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."kiosk_tokens" (
    "id" bigint NOT NULL,
    "token" "text" NOT NULL,
    "site_id" "uuid" NOT NULL,
    "active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "public"."kiosk_tokens" OWNER TO "postgres";


ALTER TABLE "public"."kiosk_tokens" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."kiosk_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."kiosk_users" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "full_name" "text" NOT NULL,
    "pin" "text",
    "role" "text" DEFAULT 'staff'::"text" NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "pin_hash" "text",
    "pin_hmac" "text",
    "team_id" bigint,
    "team_name" "text",
    "reports_to_id" bigint,
    CONSTRAINT "check_user_cannot_report_to_self" CHECK (("id" <> "reports_to_id"))
);


ALTER TABLE "public"."kiosk_users" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."kiosk_users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."kiosk_users_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."kiosk_users_id_seq" OWNED BY "public"."kiosk_users"."id";



CREATE TABLE IF NOT EXISTS "public"."teams" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "name" "text" NOT NULL
);


ALTER TABLE "public"."teams" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."kiosk_users_with_team" AS
 SELECT "ku"."id",
    "ku"."site_id",
    "ku"."full_name",
    "ku"."pin",
    "ku"."role",
    "ku"."active",
    "ku"."created_at",
    "ku"."pin_hash",
    "ku"."pin_hmac",
    "ku"."team_id",
    "t"."name" AS "team_name"
   FROM ("public"."kiosk_users" "ku"
     LEFT JOIN "public"."teams" "t" ON (("t"."id" = "ku"."team_id")));


ALTER VIEW "public"."kiosk_users_with_team" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."pir_documents" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "title" "text" NOT NULL,
    "category" "text" NOT NULL,
    "item_type" "text" NOT NULL,
    "status" "text" DEFAULT 'Not Attached'::"text" NOT NULL,
    "last_updated" "date",
    "file_path" "text",
    "data" "jsonb" DEFAULT '{}'::"jsonb"
);


ALTER TABLE "public"."pir_documents" OWNER TO "postgres";


COMMENT ON TABLE "public"."pir_documents" IS 'Tracks CQC pre-inspection required documents and their status.';



COMMENT ON COLUMN "public"."pir_documents"."item_type" IS 'Defines the UI for data entry, e.g., file_only, textarea.';



COMMENT ON COLUMN "public"."pir_documents"."data" IS 'Stores structured data like text, numbers, or table rows.';



ALTER TABLE "public"."pir_documents" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."pir_documents_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "user_id" "uuid" NOT NULL,
    "site_id" bigint NOT NULL,
    "role" "text" DEFAULT 'member'::"text" NOT NULL,
    "full_name" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "org_id" "uuid",
    CONSTRAINT "profiles_role_chk" CHECK (("role" = ANY (ARRAY['owner'::"text", 'admin'::"text", 'member'::"text"])))
);


ALTER TABLE "public"."profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."role_permissions" (
    "role" "text" NOT NULL,
    "allowed_pages" "jsonb" NOT NULL
);


ALTER TABLE "public"."role_permissions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."rooms" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "name" "text" NOT NULL,
    "occupied_by" bigint,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."rooms" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."rooms_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."rooms_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."rooms_id_seq" OWNED BY "public"."rooms"."id";



CREATE TABLE IF NOT EXISTS "public"."submission_rows" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "submission_id" bigint NOT NULL,
    "item_id" "text" NOT NULL,
    "check_type" "text" NOT NULL,
    "check_value" "text" DEFAULT 'Done'::"text" NOT NULL,
    "row_comment" "text",
    "check_type_id" bigint,
    "item_pk" bigint
);


ALTER TABLE "public"."submission_rows" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."submissions" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "session_id" "text" NOT NULL,
    "staff_name" "text" NOT NULL,
    "submitted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "comment" "text" DEFAULT ''::"text",
    "staff_id" bigint
);


ALTER TABLE "public"."submissions" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_last_submission" AS
 SELECT "sr"."site_id",
    "sr"."item_pk" AS "item_id",
    "sr"."check_type_id",
    "max"("s"."submitted_at") AS "last_done_at"
   FROM ("public"."submission_rows" "sr"
     JOIN "public"."submissions" "s" ON (("s"."id" = "sr"."submission_id")))
  GROUP BY "sr"."site_id", "sr"."item_pk", "sr"."check_type_id";


ALTER VIEW "public"."v_last_submission" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."schedules_view" AS
 WITH "base" AS (
         SELECT "iat"."id",
            "iat"."site_id",
            "i"."item_name",
            "i"."room" AS "room_name",
            "ct"."name" AS "check_type_name",
            "ct"."category" AS "check_type_category",
            "iat"."frequency",
            "iat"."warn_before",
            "iat"."required",
            "iat"."active",
            "iat"."created_at" AS "schedule_created_at",
            "iat"."item_id",
            "iat"."check_type_id",
            COALESCE("ls"."last_done_at", "iat"."created_at") AS "last_done_at"
           FROM ((("public"."item_allowed_types" "iat"
             JOIN "public"."items" "i" ON ((("i"."id" = "iat"."item_id") AND "i"."active")))
             JOIN "public"."check_types" "ct" ON ((("ct"."id" = "iat"."check_type_id") AND "ct"."active")))
             LEFT JOIN "public"."v_last_submission" "ls" ON ((("ls"."item_id" = "iat"."item_id") AND ("ls"."check_type_id" = "iat"."check_type_id"))))
          WHERE ("iat"."active" AND ("iat"."frequency" > '00:00:00'::interval))
        )
 SELECT "b"."id",
    "b"."site_id",
    "b"."item_name",
    "b"."room_name",
    "b"."check_type_name",
    "b"."check_type_category",
    "b"."frequency",
    "b"."warn_before",
    "b"."required",
    "b"."active",
    "gs"."gs" AS "created_at",
    "b"."item_id",
    "b"."check_type_id"
   FROM ("base" "b"
     JOIN LATERAL "generate_series"(
        CASE
            WHEN ("b"."last_done_at" IS NOT NULL) THEN ("b"."last_done_at" + "b"."frequency")
            ELSE ("b"."schedule_created_at" + "b"."frequency")
        END, ("now"() + '1 year'::interval), "b"."frequency") "gs"("gs") ON (true));


ALTER VIEW "public"."schedules_view" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."site_invites" (
    "id" bigint NOT NULL,
    "site_id" bigint NOT NULL,
    "email" "text" NOT NULL,
    "role" "text" NOT NULL,
    "invited_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "accepted_at" timestamp with time zone,
    "token" "uuid" DEFAULT "gen_random_uuid"(),
    "allowed_pages" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '7 days'::interval) NOT NULL,
    "full_name" "text",
    CONSTRAINT "site_invites_role_check" CHECK (("role" = ANY (ARRAY['admin'::"text", 'member'::"text"]))),
    CONSTRAINT "site_invites_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'accepted'::"text", 'revoked'::"text"])))
);


ALTER TABLE "public"."site_invites" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."site_invites_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."site_invites_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."site_invites_id_seq" OWNED BY "public"."site_invites"."id";



CREATE TABLE IF NOT EXISTS "public"."sites" (
    "id" bigint NOT NULL,
    "name" "text" NOT NULL,
    "city" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."sites" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."sites_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."sites_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."sites_id_seq" OWNED BY "public"."sites"."id";



CREATE SEQUENCE IF NOT EXISTS "public"."submission_rows_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."submission_rows_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."submission_rows_id_seq" OWNED BY "public"."submission_rows"."id";



CREATE SEQUENCE IF NOT EXISTS "public"."submissions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."submissions_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."submissions_id_seq" OWNED BY "public"."submissions"."id";



CREATE TABLE IF NOT EXISTS "public"."surgery_settings" (
    "id" bigint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "site_id" bigint NOT NULL,
    "practice_name" "text" NOT NULL,
    "practice_code" "text" NOT NULL,
    "address_line1" "text" NOT NULL,
    "address_line2" "text",
    "city" "text" NOT NULL,
    "county" "text",
    "postcode" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "email" "text" NOT NULL,
    "contract_type" "text" NOT NULL,
    "icb" "text" NOT NULL,
    "list_size" integer,
    "partner_count" integer,
    "cqc_number" "text" NOT NULL,
    "last_inspection_date" "date",
    "opening_hours" "text" NOT NULL,
    "additional_services" "text",
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    CONSTRAINT "surgery_settings_contract_type_check" CHECK (("contract_type" = ANY (ARRAY['GMS'::"text", 'PMS'::"text", 'APMS'::"text"]))),
    CONSTRAINT "surgery_settings_cqc_number_check" CHECK (("cqc_number" ~ '^[0-9-]+$'::"text")),
    CONSTRAINT "surgery_settings_email_check" CHECK (("email" ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::"text")),
    CONSTRAINT "surgery_settings_list_size_check" CHECK (("list_size" > 0)),
    CONSTRAINT "surgery_settings_partner_count_check" CHECK (("partner_count" >= 0)),
    CONSTRAINT "surgery_settings_postcode_check" CHECK (("postcode" ~ '^[A-Z]{1,2}\d[A-Z\d]? ?\d[A-Z]{2}$'::"text")),
    CONSTRAINT "surgery_settings_practice_code_check" CHECK (("practice_code" ~ '^[A-Z]\d{5}$'::"text"))
);


ALTER TABLE "public"."surgery_settings" OWNER TO "postgres";


ALTER TABLE "public"."surgery_settings" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."surgery_settings_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."team_members" (
    "site_id" bigint NOT NULL,
    "team_id" bigint NOT NULL,
    "user_id" bigint NOT NULL
);


ALTER TABLE "public"."team_members" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."teams_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."teams_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."teams_id_seq" OWNED BY "public"."teams"."id";



CREATE TABLE IF NOT EXISTS "public"."training_records" (
    "id" integer NOT NULL,
    "site_id" integer NOT NULL,
    "staff_id" integer NOT NULL,
    "training_type_id" integer NOT NULL,
    "completion_date" "date" NOT NULL,
    "expiry_date" "date",
    "certificate_url" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."training_records" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."training_records_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."training_records_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."training_records_id_seq" OWNED BY "public"."training_records"."id";



CREATE TABLE IF NOT EXISTS "public"."training_types" (
    "id" integer NOT NULL,
    "site_id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "description" "text",
    "validity_months" integer,
    "is_clinical_required" boolean DEFAULT false,
    "is_non_clinical_required" boolean DEFAULT false,
    "active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."training_types" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."training_types_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."training_types_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."training_types_id_seq" OWNED BY "public"."training_types"."id";



CREATE TABLE IF NOT EXISTS "public"."user_permissions" (
    "user_id" "uuid" NOT NULL,
    "site_id" bigint NOT NULL,
    "allowed_pages" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL
);


ALTER TABLE "public"."user_permissions" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_item_check_latest" AS
 WITH "last_done" AS (
         SELECT "sr"."site_id",
            COALESCE("sr"."item_pk", "i"."id") AS "item_pk",
            COALESCE("sr"."check_type_id", "ct"."id") AS "check_type_id",
            "max"("s"."submitted_at") AS "last_done_at"
           FROM ((("public"."submission_rows" "sr"
             JOIN "public"."submissions" "s" ON ((("s"."id" = "sr"."submission_id") AND ("s"."site_id" = "sr"."site_id"))))
             LEFT JOIN "public"."items" "i" ON ((("i"."site_id" = "sr"."site_id") AND ("i"."item_id" = "sr"."item_id"))))
             LEFT JOIN "public"."check_types" "ct" ON ((("ct"."site_id" = "sr"."site_id") AND ("ct"."name" = "sr"."check_type"))))
          GROUP BY "sr"."site_id", COALESCE("sr"."item_pk", "i"."id"), COALESCE("sr"."check_type_id", "ct"."id")
        )
 SELECT "site_id",
    "item_pk",
    "check_type_id",
    "last_done_at"
   FROM "last_done";


ALTER VIEW "public"."v_item_check_latest" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_item_check_status" AS
 WITH "base" AS (
         SELECT "iat"."site_id",
            "i"."id" AS "item_id",
            "i"."item_id" AS "item_code",
            "i"."item_name",
            "i"."room" AS "room_name",
            "ct"."id" AS "check_type_id",
            "ct"."name" AS "check_type",
            "iat"."frequency",
            "iat"."warn_before",
            "iat"."required",
            "iat"."responsible_team_id" AS "effective_team_id",
            "t"."name" AS "effective_team_name",
            "ls"."last_done_at",
                CASE
                    WHEN ("ls"."last_done_at" IS NOT NULL) THEN ("ls"."last_done_at" + "iat"."frequency")
                    ELSE ("iat"."created_at" + "iat"."frequency")
                END AS "next_due_at"
           FROM (((("public"."item_allowed_types" "iat"
             JOIN "public"."items" "i" ON ((("i"."id" = "iat"."item_id") AND "i"."active")))
             JOIN "public"."check_types" "ct" ON ((("ct"."id" = "iat"."check_type_id") AND "ct"."active")))
             LEFT JOIN "public"."teams" "t" ON (("t"."id" = "iat"."responsible_team_id")))
             LEFT JOIN "public"."v_last_submission" "ls" ON ((("ls"."item_id" = "iat"."item_id") AND ("ls"."check_type_id" = "iat"."check_type_id"))))
          WHERE ("iat"."active" AND ("iat"."frequency" > '00:00:00'::interval))
        )
 SELECT "site_id",
    "item_id",
    "item_code",
    "item_name",
    "room_name",
    "check_type_id",
    "check_type",
    "frequency",
    "warn_before",
    "required",
    "effective_team_id",
    "effective_team_name",
    "last_done_at",
    "next_due_at",
        CASE
            WHEN ("now"() >= "next_due_at") THEN 'overdue'::"text"
            WHEN ("now"() >= ("next_due_at" - "warn_before")) THEN 'due_soon'::"text"
            ELSE 'ok'::"text"
        END AS "status"
   FROM "base";


ALTER VIEW "public"."v_item_check_status" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_item_check_summary" AS
 SELECT "site_id",
    "status",
    ("count"(*))::integer AS "count"
   FROM "public"."v_item_check_status"
  GROUP BY "site_id", "status";


ALTER VIEW "public"."v_item_check_summary" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_item_schedule_resolved" AS
 SELECT "iat"."id",
    "iat"."site_id",
    "iat"."item_id",
    "it"."item_id" AS "item_code",
    "it"."item_name",
    "it"."room_id",
    "r"."name" AS "room_name",
    "iat"."check_type_id",
    "ct"."name" AS "check_type",
    "iat"."frequency",
    "iat"."warn_before",
    "iat"."required",
    "iat"."active",
    COALESCE("iat"."responsible_team_id", "ctt"."team_id") AS "effective_team_id",
    "t"."name" AS "effective_team_name"
   FROM ((((("public"."item_allowed_types" "iat"
     JOIN "public"."items" "it" ON (("it"."id" = "iat"."item_id")))
     LEFT JOIN "public"."rooms" "r" ON (("r"."id" = "it"."room_id")))
     JOIN "public"."check_types" "ct" ON (("ct"."id" = "iat"."check_type_id")))
     LEFT JOIN "public"."check_type_teams" "ctt" ON ((("ctt"."site_id" = "iat"."site_id") AND ("ctt"."check_type_id" = "ct"."id"))))
     LEFT JOIN "public"."teams" "t" ON (("t"."id" = COALESCE("iat"."responsible_team_id", "ctt"."team_id"))));


ALTER VIEW "public"."v_item_schedule_resolved" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_items_admin" AS
 SELECT "i"."id",
    "i"."site_id",
    "i"."item_id",
    "i"."item_name",
    "i"."category",
    "i"."active",
    "i"."room_id",
    "r"."name" AS "room_name",
    "i"."default_check_type_id",
    "ct"."name" AS "default_check_type_name",
    "i"."comments"
   FROM (("public"."items" "i"
     LEFT JOIN "public"."rooms" "r" ON (("r"."id" = "i"."room_id")))
     LEFT JOIN "public"."check_types" "ct" ON (("ct"."id" = "i"."default_check_type_id")));


ALTER VIEW "public"."v_items_admin" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_kiosk_users_with_manager" AS
 SELECT "ku"."id",
    "ku"."site_id",
    "ku"."full_name",
    "ku"."pin",
    "ku"."role",
    "ku"."active",
    "ku"."created_at",
    "ku"."pin_hash",
    "ku"."pin_hmac",
    "ku"."team_id",
    "ku"."team_name",
    "ku"."reports_to_id",
    "m"."full_name" AS "manager_name"
   FROM ("public"."kiosk_users" "ku"
     LEFT JOIN "public"."kiosk_users" "m" ON (("m"."id" = "ku"."reports_to_id")));


ALTER VIEW "public"."v_kiosk_users_with_manager" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_my_profile" AS
 SELECT "user_id",
    "site_id",
    "role"
   FROM "public"."profiles" "p"
  WHERE ("user_id" = "auth"."uid"());


ALTER VIEW "public"."v_my_profile" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_submission_detail" AS
 SELECT "s"."id" AS "submission_id",
    "s"."site_id",
    "s"."session_id",
    "s"."submitted_at",
    COALESCE("ku"."full_name", "s"."staff_name") AS "staff_name",
    "sr"."id" AS "row_id",
    "sr"."item_id" AS "scanned_code",
    "i"."item_name",
    "r"."name" AS "room",
    COALESCE("ct"."name", "sr"."check_type") AS "check_type",
    "sr"."check_value"
   FROM ((((("public"."submissions" "s"
     JOIN "public"."submission_rows" "sr" ON (("sr"."submission_id" = "s"."id")))
     LEFT JOIN "public"."items" "i" ON ((("i"."site_id" = "sr"."site_id") AND ("i"."item_id" = "sr"."item_id"))))
     LEFT JOIN "public"."rooms" "r" ON (("r"."id" = "i"."room_id")))
     LEFT JOIN "public"."check_types" "ct" ON (("ct"."id" = "sr"."check_type_id")))
     LEFT JOIN "public"."kiosk_users" "ku" ON (("ku"."id" = "s"."staff_id")));


ALTER VIEW "public"."v_submission_detail" OWNER TO "postgres";


ALTER TABLE ONLY "public"."check_types" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."check_types_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."item_allowed_types" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."item_allowed_types_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."items" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."items_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."kiosk_users" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."kiosk_users_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."rooms" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."rooms_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."site_invites" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."site_invites_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."sites" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."sites_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."submission_rows" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."submission_rows_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."submissions" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."submissions_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."teams" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."teams_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."training_records" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."training_records_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."training_types" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."training_types_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."check_events"
    ADD CONSTRAINT "check_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."check_type_teams"
    ADD CONSTRAINT "check_type_teams_pkey" PRIMARY KEY ("site_id", "check_type_id");



ALTER TABLE ONLY "public"."check_types"
    ADD CONSTRAINT "check_types_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."check_types"
    ADD CONSTRAINT "check_types_site_id_name_key" UNIQUE ("site_id", "name");



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_unique" UNIQUE ("site_id", "item_id", "check_type_id");



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_site_id_item_id_key" UNIQUE ("site_id", "item_id");



ALTER TABLE ONLY "public"."kiosk_roles"
    ADD CONSTRAINT "kiosk_roles_pkey" PRIMARY KEY ("role");



ALTER TABLE ONLY "public"."kiosk_tokens"
    ADD CONSTRAINT "kiosk_tokens_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."kiosk_tokens"
    ADD CONSTRAINT "kiosk_tokens_token_key" UNIQUE ("token");



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_id_site_unique" UNIQUE ("id", "site_id");



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."pir_documents"
    ADD CONSTRAINT "pir_documents_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."role_permissions"
    ADD CONSTRAINT "role_permissions_pkey" PRIMARY KEY ("role");



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."site_invites"
    ADD CONSTRAINT "site_invites_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."site_invites"
    ADD CONSTRAINT "site_invites_site_email_unique" UNIQUE ("site_id", "email");



ALTER TABLE ONLY "public"."sites"
    ADD CONSTRAINT "sites_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."submission_rows"
    ADD CONSTRAINT "submission_rows_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."surgery_settings"
    ADD CONSTRAINT "surgery_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."surgery_settings"
    ADD CONSTRAINT "surgery_settings_site_id_key" UNIQUE ("site_id");



ALTER TABLE ONLY "public"."team_members"
    ADD CONSTRAINT "team_members_pkey" PRIMARY KEY ("site_id", "team_id", "user_id");



ALTER TABLE ONLY "public"."teams"
    ADD CONSTRAINT "teams_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."teams"
    ADD CONSTRAINT "teams_site_id_name_key" UNIQUE ("site_id", "name");



ALTER TABLE ONLY "public"."training_records"
    ADD CONSTRAINT "training_records_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."training_records"
    ADD CONSTRAINT "training_records_site_id_staff_id_training_type_id_key" UNIQUE ("site_id", "staff_id", "training_type_id");



ALTER TABLE ONLY "public"."training_types"
    ADD CONSTRAINT "training_types_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_permissions"
    ADD CONSTRAINT "user_permissions_pkey" PRIMARY KEY ("user_id", "site_id");



CREATE INDEX "check_types_site_id_idx" ON "public"."check_types" USING "btree" ("site_id");



CREATE INDEX "ctt_site_team_idx" ON "public"."check_type_teams" USING "btree" ("site_id", "team_id");



CREATE INDEX "ctt_site_type_idx" ON "public"."check_type_teams" USING "btree" ("site_id", "check_type_id");



CREATE INDEX "iat_site_item_idx" ON "public"."item_allowed_types" USING "btree" ("site_id", "item_id");



CREATE INDEX "iat_site_item_type_active_idx" ON "public"."item_allowed_types" USING "btree" ("site_id", "item_id", "check_type_id") WHERE "active";



CREATE INDEX "iat_site_team_idx" ON "public"."item_allowed_types" USING "btree" ("site_id", "responsible_team_id");



CREATE INDEX "idx_training_records_expiry_date" ON "public"."training_records" USING "btree" ("expiry_date");



CREATE INDEX "idx_training_records_site_id" ON "public"."training_records" USING "btree" ("site_id");



CREATE INDEX "idx_training_records_staff_id" ON "public"."training_records" USING "btree" ("staff_id");



CREATE INDEX "idx_training_records_training_type_id" ON "public"."training_records" USING "btree" ("training_type_id");



CREATE INDEX "idx_training_types_site_id" ON "public"."training_types" USING "btree" ("site_id");



CREATE INDEX "items_default_check_type_id_idx" ON "public"."items" USING "btree" ("default_check_type_id");



CREATE INDEX "items_room_id_idx" ON "public"."items" USING "btree" ("room_id");



CREATE INDEX "items_site_default_type_idx" ON "public"."items" USING "btree" ("site_id", "default_check_type");



CREATE INDEX "items_site_id_idx" ON "public"."items" USING "btree" ("site_id");



CREATE UNIQUE INDEX "kiosk_users_site_pin_hmac_uq" ON "public"."kiosk_users" USING "btree" ("site_id", "pin_hmac");



CREATE INDEX "kiosk_users_team_id_idx" ON "public"."kiosk_users" USING "btree" ("team_id");



CREATE INDEX "profiles_site_id_idx" ON "public"."profiles" USING "btree" ("site_id");



CREATE INDEX "rooms_occupied_by_idx" ON "public"."rooms" USING "btree" ("occupied_by");



CREATE INDEX "rooms_site_id_idx" ON "public"."rooms" USING "btree" ("site_id");



CREATE UNIQUE INDEX "rooms_site_name_key" ON "public"."rooms" USING "btree" ("site_id", "name");



CREATE INDEX "site_invites_email_idx" ON "public"."site_invites" USING "btree" ("lower"("email"));



CREATE INDEX "site_invites_site_email_status_idx" ON "public"."site_invites" USING "btree" ("site_id", "lower"("email"), "status");



CREATE INDEX "site_invites_site_id_idx" ON "public"."site_invites" USING "btree" ("site_id");



CREATE INDEX "site_invites_site_idx" ON "public"."site_invites" USING "btree" ("site_id");



CREATE INDEX "site_invites_token_idx" ON "public"."site_invites" USING "btree" ("token");



CREATE INDEX "sites_name_idx" ON "public"."sites" USING "btree" ("name");



CREATE INDEX "sr_site_item_type_idx" ON "public"."submission_rows" USING "btree" ("site_id", "item_pk", "check_type_id");



CREATE INDEX "submission_rows_check_type_id_idx" ON "public"."submission_rows" USING "btree" ("check_type_id");



CREATE INDEX "submission_rows_item_pk_idx" ON "public"."submission_rows" USING "btree" ("item_pk");



CREATE INDEX "submission_rows_site_id_submission_id_idx" ON "public"."submission_rows" USING "btree" ("site_id", "submission_id");



CREATE INDEX "submissions_site_id_idx" ON "public"."submissions" USING "btree" ("site_id");



CREATE INDEX "submissions_site_time_idx" ON "public"."submissions" USING "btree" ("site_id", "submitted_at" DESC);



CREATE INDEX "submissions_staff_id_idx" ON "public"."submissions" USING "btree" ("staff_id");



CREATE INDEX "surgery_settings_practice_code_idx" ON "public"."surgery_settings" USING "btree" ("practice_code");



CREATE INDEX "surgery_settings_site_id_idx" ON "public"."surgery_settings" USING "btree" ("site_id");



CREATE INDEX "team_members_site_team_idx" ON "public"."team_members" USING "btree" ("site_id", "team_id");



CREATE INDEX "team_members_site_user_idx" ON "public"."team_members" USING "btree" ("site_id", "user_id");



CREATE INDEX "teams_site_id_idx" ON "public"."teams" USING "btree" ("site_id");



CREATE OR REPLACE TRIGGER "pir_documents_status_biub" BEFORE INSERT OR UPDATE ON "public"."pir_documents" FOR EACH ROW EXECUTE FUNCTION "public"."set_pir_document_status"();



CREATE OR REPLACE TRIGGER "set_updated_at" BEFORE UPDATE ON "public"."surgery_settings" FOR EACH ROW EXECUTE FUNCTION "public"."handle_updated_at"();



CREATE OR REPLACE TRIGGER "trg_items_sync_default_type" BEFORE INSERT OR UPDATE OF "default_check_type_id" ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."items_sync_default_type_text"();



CREATE OR REPLACE TRIGGER "trg_items_sync_room" BEFORE INSERT OR UPDATE OF "room_id", "room" ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."items_sync_room_text"();



CREATE OR REPLACE TRIGGER "trg_kiosk_users_hash_pin" BEFORE INSERT OR UPDATE OF "pin" ON "public"."kiosk_users" FOR EACH ROW EXECUTE FUNCTION "public"."kiosk_users_hash_pin"();



CREATE OR REPLACE TRIGGER "trg_kiosk_users_sync_team_name" BEFORE INSERT OR UPDATE OF "team_id" ON "public"."kiosk_users" FOR EACH ROW EXECUTE FUNCTION "public"."kiosk_users_sync_team_name"();



CREATE OR REPLACE TRIGGER "trg_submission_rows_sync_type" BEFORE INSERT OR UPDATE OF "check_type_id" ON "public"."submission_rows" FOR EACH ROW EXECUTE FUNCTION "public"."submission_rows_sync_check_type_text"();



CREATE OR REPLACE TRIGGER "trg_submissions_sync_staff" BEFORE INSERT OR UPDATE OF "staff_id" ON "public"."submissions" FOR EACH ROW EXECUTE FUNCTION "public"."submissions_sync_staff_name"();



CREATE OR REPLACE TRIGGER "trg_teams_cascade_name_to_users" AFTER UPDATE OF "name" ON "public"."teams" FOR EACH ROW EXECUTE FUNCTION "public"."teams_cascade_name_to_users"();



CREATE OR REPLACE TRIGGER "update_training_records_updated_at" BEFORE UPDATE ON "public"."training_records" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();



CREATE OR REPLACE TRIGGER "update_training_types_updated_at" BEFORE UPDATE ON "public"."training_types" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();



ALTER TABLE ONLY "public"."check_type_teams"
    ADD CONSTRAINT "check_type_teams_check_type_id_fkey" FOREIGN KEY ("check_type_id") REFERENCES "public"."check_types"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."check_type_teams"
    ADD CONSTRAINT "check_type_teams_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."check_type_teams"
    ADD CONSTRAINT "check_type_teams_team_id_fkey" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."check_types"
    ADD CONSTRAINT "check_types_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_check_type_id_fkey" FOREIGN KEY ("check_type_id") REFERENCES "public"."check_types"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_responsible_team_id_fkey" FOREIGN KEY ("responsible_team_id") REFERENCES "public"."teams"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."item_allowed_types"
    ADD CONSTRAINT "item_allowed_types_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_default_check_type_fkey" FOREIGN KEY ("site_id", "default_check_type") REFERENCES "public"."check_types"("site_id", "name") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_default_check_type_id_fk" FOREIGN KEY ("default_check_type_id") REFERENCES "public"."check_types"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_room_fk" FOREIGN KEY ("room_id") REFERENCES "public"."rooms"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_reports_to_id_fkey" FOREIGN KEY ("reports_to_id") REFERENCES "public"."kiosk_users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_role_fkey" FOREIGN KEY ("role") REFERENCES "public"."kiosk_roles"("role") ON UPDATE CASCADE ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."kiosk_users"
    ADD CONSTRAINT "kiosk_users_team_id_fkey" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."pir_documents"
    ADD CONSTRAINT "pir_documents_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_occupied_by_fk" FOREIGN KEY ("occupied_by", "site_id") REFERENCES "public"."kiosk_users"("id", "site_id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."rooms"
    ADD CONSTRAINT "rooms_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."site_invites"
    ADD CONSTRAINT "site_invites_invited_by_fkey" FOREIGN KEY ("invited_by") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."site_invites"
    ADD CONSTRAINT "site_invites_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submission_rows"
    ADD CONSTRAINT "submission_rows_check_type_fk" FOREIGN KEY ("check_type_id") REFERENCES "public"."check_types"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."submission_rows"
    ADD CONSTRAINT "submission_rows_item_pk_fk" FOREIGN KEY ("item_pk") REFERENCES "public"."items"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."submission_rows"
    ADD CONSTRAINT "submission_rows_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submission_rows"
    ADD CONSTRAINT "submission_rows_submission_id_fkey" FOREIGN KEY ("submission_id") REFERENCES "public"."submissions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."submissions"
    ADD CONSTRAINT "submissions_staff_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."kiosk_users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."surgery_settings"
    ADD CONSTRAINT "surgery_settings_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id");



ALTER TABLE ONLY "public"."team_members"
    ADD CONSTRAINT "team_members_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."team_members"
    ADD CONSTRAINT "team_members_team_id_fkey" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."team_members"
    ADD CONSTRAINT "team_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."kiosk_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."teams"
    ADD CONSTRAINT "teams_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."training_records"
    ADD CONSTRAINT "training_records_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."training_records"
    ADD CONSTRAINT "training_records_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "public"."kiosk_users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."training_records"
    ADD CONSTRAINT "training_records_training_type_id_fkey" FOREIGN KEY ("training_type_id") REFERENCES "public"."training_types"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."training_types"
    ADD CONSTRAINT "training_types_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_permissions"
    ADD CONSTRAINT "user_permissions_site_id_fkey" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_permissions"
    ADD CONSTRAINT "user_permissions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



CREATE POLICY "Admins can CRUD schedules in their site" ON "public"."item_allowed_types" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "item_allowed_types"."site_id") AND ("p"."role" = ANY (ARRAY['admin'::"text", 'owner'::"text"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "item_allowed_types"."site_id") AND ("p"."role" = ANY (ARRAY['admin'::"text", 'owner'::"text"]))))));



CREATE POLICY "Allow authenticated users to delete teams" ON "public"."teams" FOR DELETE TO "authenticated" USING (true);



CREATE POLICY "Allow authenticated users to insert submissions" ON "public"."submission_rows" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Allow authenticated users to insert submissions" ON "public"."submissions" FOR INSERT TO "authenticated" WITH CHECK (("site_id" = ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow authenticated users to insert teams" ON "public"."teams" FOR INSERT TO "authenticated" WITH CHECK (("site_id" = ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow users to insert documents for their own site" ON "public"."pir_documents" FOR INSERT WITH CHECK (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow users to update documents for their own site" ON "public"."pir_documents" FOR UPDATE USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow users to view all check types from their site" ON "public"."check_types" FOR SELECT TO "authenticated" USING (("site_id" = ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow users to view all teams from their own site" ON "public"."teams" FOR SELECT TO "authenticated" USING (("site_id" = ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Allow users to view documents for their own site" ON "public"."pir_documents" FOR SELECT USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Sites readable for authenticated" ON "public"."sites" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Sites readable for signup" ON "public"."sites" FOR SELECT TO "anon" USING (true);



CREATE POLICY "User can insert own profile" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "User can read own profile" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "Users can insert settings for their site" ON "public"."surgery_settings" FOR INSERT WITH CHECK (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can manage training records for their site" ON "public"."training_records" USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can manage training types for their site" ON "public"."training_types" USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can update their site's settings" ON "public"."surgery_settings" FOR UPDATE USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"())))) WITH CHECK (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can view their site's settings" ON "public"."surgery_settings" FOR SELECT USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can view training records for their site" ON "public"."training_records" FOR SELECT USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can view training types for their site" ON "public"."training_types" FOR SELECT USING (("site_id" IN ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "admin check_types in my site" ON "public"."check_types" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "admin items in my site" ON "public"."items" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "admin kiosk users in my site" ON "public"."kiosk_users" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "admin rooms in my site" ON "public"."rooms" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



ALTER TABLE "public"."check_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "check_events: kiosk insert via token" ON "public"."check_events" FOR INSERT TO "anon" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."kiosk_tokens" "kt"
  WHERE ("kt"."active" AND ("kt"."token" = "public"."auth_device_token"()) AND ("kt"."site_id" = "check_events"."site_id")))));



ALTER TABLE "public"."check_type_teams" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "check_type_teams same-site rw" ON "public"."check_type_teams" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



ALTER TABLE "public"."check_types" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "check_types same-site rw" ON "public"."check_types" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "ctt_admin_all" ON "public"."check_type_teams" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "ctt_select_mine" ON "public"."check_type_teams" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "inv_admin_all" ON "public"."site_invites" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "inv_read_by_email" ON "public"."site_invites" FOR SELECT TO "authenticated" USING (("lower"("email") = "lower"((( SELECT "users"."email"
   FROM "auth"."users"
  WHERE ("users"."id" = "auth"."uid"())))::"text")));



CREATE POLICY "inv_select_mine" ON "public"."site_invites" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "inv_update_by_email" ON "public"."site_invites" FOR UPDATE TO "authenticated" USING (("lower"("email") = "lower"((( SELECT "users"."email"
   FROM "auth"."users"
  WHERE ("users"."id" = "auth"."uid"())))::"text"))) WITH CHECK (("lower"("email") = "lower"((( SELECT "users"."email"
   FROM "auth"."users"
  WHERE ("users"."id" = "auth"."uid"())))::"text")));



ALTER TABLE "public"."item_allowed_types" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."items" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "items same-site rw" ON "public"."items" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "items: read same org" ON "public"."items" FOR SELECT TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "items: write same org" ON "public"."items" TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id")) WITH CHECK ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "items_ins" ON "public"."items" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "items_insert" ON "public"."items" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "items_select" ON "public"."items" FOR SELECT USING ("public"."is_member"("site_id"));



CREATE POLICY "items_upd" ON "public"."items" FOR UPDATE USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "kiosk_read_items_site1" ON "public"."items" FOR SELECT TO "anon" USING (("site_id" = 1));



ALTER TABLE "public"."kiosk_tokens" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."kiosk_users" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "kiosk_users same-site r" ON "public"."kiosk_users" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "p"."site_id")))));



CREATE POLICY "kiosk_users same-site u" ON "public"."kiosk_users" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "p"."site_id"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "p"."site_id")))));



CREATE POLICY "kiosk_users same-site w" ON "public"."kiosk_users" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "p"."site_id")))));



CREATE POLICY "kiosk_users: read same org" ON "public"."kiosk_users" FOR SELECT TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "kiosk_users: write same org" ON "public"."kiosk_users" TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id")) WITH CHECK ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "ku_delete" ON "public"."kiosk_users" FOR DELETE USING ("public"."is_member"("site_id"));



CREATE POLICY "ku_insert" ON "public"."kiosk_users" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "ku_select" ON "public"."kiosk_users" FOR SELECT USING ("public"."is_member"("site_id"));



CREATE POLICY "ku_update" ON "public"."kiosk_users" FOR UPDATE USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "members submit in my site" ON "public"."submissions" FOR INSERT TO "authenticated" WITH CHECK (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "members submit rows in my site" ON "public"."submission_rows" FOR INSERT TO "authenticated" WITH CHECK (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



ALTER TABLE "public"."pir_documents" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "profile: insert self" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "profile: read own" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "profile: read same org" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("org_id" = "public"."get_current_user_org_id"()));



CREATE POLICY "profile: update self" ON "public"."profiles" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "profiles_self_insert_if_invited" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."site_invites" "si"
  WHERE (("lower"("si"."email") = "lower"((( SELECT "u"."email"
           FROM "auth"."users" "u"
          WHERE ("u"."id" = "auth"."uid"())))::"text")) AND ("si"."site_id" = "profiles"."site_id") AND ("si"."status" = ANY (ARRAY['pending'::"text", 'approved'::"text"])))))));



CREATE POLICY "profiles_self_insert_owner" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "profiles_self_update_self" ON "public"."profiles" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "read own profile" ON "public"."profiles" FOR SELECT USING (("user_id" = "auth"."uid"()));



CREATE POLICY "read submission rows in my site" ON "public"."submission_rows" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "read submissions in my site" ON "public"."submissions" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



ALTER TABLE "public"."role_permissions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."rooms" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "rooms same-site rw" ON "public"."rooms" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "rooms: read same org" ON "public"."rooms" FOR SELECT TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "rooms: write same org" ON "public"."rooms" TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id")) WITH CHECK ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "rooms_delete" ON "public"."rooms" FOR DELETE USING ("public"."is_member"("site_id"));



CREATE POLICY "rooms_insert" ON "public"."rooms" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "rooms_select" ON "public"."rooms" FOR SELECT USING ("public"."is_member"("site_id"));



CREATE POLICY "rooms_update" ON "public"."rooms" FOR UPDATE USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "rp_select_all" ON "public"."role_permissions" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "select check_types in my site" ON "public"."check_types" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "select items in my site" ON "public"."items" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "select kiosk users in my site" ON "public"."kiosk_users" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "select rooms in my site" ON "public"."rooms" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



ALTER TABLE "public"."site_invites" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "site_invites_insert" ON "public"."site_invites" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "site_invites"."site_id") AND ("p"."role" = ANY (ARRAY['owner'::"text", 'admin'::"text"]))))));



CREATE POLICY "site_invites_select" ON "public"."site_invites" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "site_invites"."site_id")))));



CREATE POLICY "site_invites_update" ON "public"."site_invites" FOR UPDATE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "site_invites"."site_id") AND ("p"."role" = ANY (ARRAY['owner'::"text", 'admin'::"text"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "site_invites"."site_id") AND ("p"."role" = ANY (ARRAY['owner'::"text", 'admin'::"text"]))))));



ALTER TABLE "public"."sites" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "sites same-site read" ON "public"."sites" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles" "p"
  WHERE (("p"."user_id" = "auth"."uid"()) AND ("p"."site_id" = "sites"."id")))));



CREATE POLICY "sites_insert_any" ON "public"."sites" FOR INSERT TO "authenticated" WITH CHECK (true);



CREATE POLICY "sites_select_if_invited" ON "public"."sites" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM ("public"."site_invites" "si"
     JOIN "auth"."users" "u" ON (("u"."id" = "auth"."uid"())))
  WHERE (("si"."site_id" = "sites"."id") AND ("lower"("si"."email") = "lower"(("u"."email")::"text")) AND ("si"."status" = ANY (ARRAY['pending'::"text", 'approved'::"text"]))))));



CREATE POLICY "sites_select_my" ON "public"."sites" FOR SELECT TO "authenticated" USING (("id" = ( SELECT "profiles"."site_id"
   FROM "public"."profiles"
  WHERE ("profiles"."user_id" = "auth"."uid"()))));



CREATE POLICY "sites_select_own" ON "public"."sites" FOR SELECT USING ("public"."is_member"("id"));



CREATE POLICY "sites_update_admin" ON "public"."sites" FOR UPDATE USING ("public"."is_site_admin"("id")) WITH CHECK ("public"."is_site_admin"("id"));



ALTER TABLE "public"."submission_rows" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "submission_rows same-site rw" ON "public"."submission_rows" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



ALTER TABLE "public"."submissions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "submissions same-site rw" ON "public"."submissions" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subrows_ins" ON "public"."submission_rows" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subrows_insert" ON "public"."submission_rows" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subrows_select" ON "public"."submission_rows" FOR SELECT USING ("public"."is_member"("site_id"));



CREATE POLICY "subrows_upd" ON "public"."submission_rows" FOR UPDATE USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subs_ins" ON "public"."submissions" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subs_insert" ON "public"."submissions" FOR INSERT WITH CHECK ("public"."is_member"("site_id"));



CREATE POLICY "subs_select" ON "public"."submissions" FOR SELECT USING ("public"."is_member"("site_id"));



ALTER TABLE "public"."surgery_settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."team_members" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "team_members same-site rw" ON "public"."team_members" USING ("public"."is_member"("site_id")) WITH CHECK ("public"."is_member"("site_id"));



ALTER TABLE "public"."teams" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "teams: read same org" ON "public"."teams" FOR SELECT TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "teams: write same org" ON "public"."teams" TO "authenticated" USING ("public"."site_belongs_to_current_org"("site_id")) WITH CHECK ("public"."site_belongs_to_current_org"("site_id"));



CREATE POLICY "teams_insert_mine" ON "public"."teams" FOR INSERT WITH CHECK (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "teams_update_mine" ON "public"."teams" FOR UPDATE USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile"))) WITH CHECK (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "tm_admin_all" ON "public"."team_members" TO "authenticated" USING ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"])))) WITH CHECK ((("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY (ARRAY['owner'::"text", 'admin'::"text"]))));



CREATE POLICY "tm_select_mine" ON "public"."team_members" FOR SELECT USING (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")));



CREATE POLICY "tmp_dev_read_items_all_auth" ON "public"."items" FOR SELECT TO "authenticated" USING (true);



ALTER TABLE "public"."training_records" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."training_types" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "up_delete_admin" ON "public"."user_permissions" FOR DELETE TO "authenticated" USING ((("user_id" = "auth"."uid"()) OR (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY ('{owner,admin}'::"text"[])))));



CREATE POLICY "up_insert_admin" ON "public"."user_permissions" FOR INSERT TO "authenticated" WITH CHECK (((("user_id" = "auth"."uid"()) AND ("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile"))) OR (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY ('{owner,admin}'::"text"[])))));



CREATE POLICY "up_select_mine" ON "public"."user_permissions" FOR SELECT TO "authenticated" USING ((("user_id" = "auth"."uid"()) OR (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY ('{owner,admin}'::"text"[])))));



CREATE POLICY "up_update_admin" ON "public"."user_permissions" FOR UPDATE TO "authenticated" USING ((("user_id" = "auth"."uid"()) OR (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY ('{owner,admin}'::"text"[]))))) WITH CHECK ((("user_id" = "auth"."uid"()) OR (("site_id" IN ( SELECT "v_my_profile"."site_id"
   FROM "public"."v_my_profile")) AND (( SELECT "v_my_profile"."role"
   FROM "public"."v_my_profile") = ANY ('{owner,admin}'::"text"[])))));



ALTER TABLE "public"."user_permissions" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";






GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";













































GRANT ALL ON FUNCTION "public"."accept_invite"("_token" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."accept_invite"("_token" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."accept_invite"("_token" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_set_item_check"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean) TO "anon";
GRANT ALL ON FUNCTION "public"."admin_set_item_check"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_set_item_check"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean) TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_set_item_check_team"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean, "p_responsible_team_id" bigint) TO "anon";
GRANT ALL ON FUNCTION "public"."admin_set_item_check_team"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean, "p_responsible_team_id" bigint) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_set_item_check_team"("p_site_id" bigint, "p_item_code" "text", "p_check_type_name" "text", "p_frequency" interval, "p_warn_before" interval, "p_required" boolean, "p_active" boolean, "p_responsible_team_id" bigint) TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_upsert_item"("p_site_id" bigint, "p_item_id" "text", "p_item_name" "text", "p_room_name" "text", "p_category" "text", "p_default_check_type_name" "text", "p_comments" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."admin_upsert_item"("p_site_id" bigint, "p_item_id" "text", "p_item_name" "text", "p_room_name" "text", "p_category" "text", "p_default_check_type_name" "text", "p_comments" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_upsert_item"("p_site_id" bigint, "p_item_id" "text", "p_item_name" "text", "p_room_name" "text", "p_category" "text", "p_default_check_type_name" "text", "p_comments" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."app_bootstrap"() TO "anon";
GRANT ALL ON FUNCTION "public"."app_bootstrap"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."app_bootstrap"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."armor"("bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "public"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."assert_admin"("p_site_id" bigint) TO "anon";
GRANT ALL ON FUNCTION "public"."assert_admin"("p_site_id" bigint) TO "authenticated";
GRANT ALL ON FUNCTION "public"."assert_admin"("p_site_id" bigint) TO "service_role";



GRANT ALL ON FUNCTION "public"."auth_check_pin"("p_site_id" bigint, "p_pin" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."auth_check_pin"("p_site_id" bigint, "p_pin" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."auth_check_pin"("p_site_id" bigint, "p_pin" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."auth_device_token"() TO "anon";
GRANT ALL ON FUNCTION "public"."auth_device_token"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."auth_device_token"() TO "service_role";



GRANT ALL ON FUNCTION "public"."calendar_events"("p_site_id" bigint, "p_from" "date", "p_to" "date") TO "anon";
GRANT ALL ON FUNCTION "public"."calendar_events"("p_site_id" bigint, "p_from" "date", "p_to" "date") TO "authenticated";
GRANT ALL ON FUNCTION "public"."calendar_events"("p_site_id" bigint, "p_from" "date", "p_to" "date") TO "service_role";



GRANT ALL ON FUNCTION "public"."check_site_invite"("p_email" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."check_site_invite"("p_email" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."check_site_invite"("p_email" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text", "_full_name" "text", "_site_id" bigint, "_invited_by" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text", "_full_name" "text", "_site_id" bigint, "_invited_by" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."create_invite"("_email" "text", "_role" "text", "_full_name" "text", "_site_id" bigint, "_invited_by" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."create_site_and_owner"("_site_name" "text", "_full_name" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."create_site_and_owner"("_site_name" "text", "_full_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."create_site_and_owner"("_site_name" "text", "_full_name" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."crypt"("text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."dearmor"("text") TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."debug_jwt"() TO "anon";
GRANT ALL ON FUNCTION "public"."debug_jwt"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."debug_jwt"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."digest"("bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."digest"("text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "public"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."gen_random_bytes"(integer) TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "public"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."gen_random_uuid"() TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."gen_salt"("text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "public"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."gen_salt"("text", integer) TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."get_current_user_org_id"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) TO "anon";
GRANT ALL ON FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_due_calendar"("p_site_id" bigint, "p_start" timestamp with time zone, "p_end" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."get_my_site_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_my_site_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_my_site_id"() TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_updated_at"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."hmac"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."hmac"("text", "text", "text") TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."insert_invite"("_site_id" bigint, "_email" "text", "_role" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."insert_invite"("_site_id" bigint, "_email" "text", "_role" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."insert_invite"("_site_id" bigint, "_email" "text", "_role" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_member"("site_id_in" bigint) TO "anon";
GRANT ALL ON FUNCTION "public"."is_member"("site_id_in" bigint) TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_member"("site_id_in" bigint) TO "service_role";



GRANT ALL ON FUNCTION "public"."is_site_admin"("site_id_in" bigint) TO "anon";
GRANT ALL ON FUNCTION "public"."is_site_admin"("site_id_in" bigint) TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_site_admin"("site_id_in" bigint) TO "service_role";



GRANT ALL ON FUNCTION "public"."items_sync_default_type_text"() TO "anon";
GRANT ALL ON FUNCTION "public"."items_sync_default_type_text"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."items_sync_default_type_text"() TO "service_role";



GRANT ALL ON FUNCTION "public"."items_sync_room_text"() TO "anon";
GRANT ALL ON FUNCTION "public"."items_sync_room_text"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."items_sync_room_text"() TO "service_role";



GRANT ALL ON FUNCTION "public"."kiosk_users_hash_pin"() TO "anon";
GRANT ALL ON FUNCTION "public"."kiosk_users_hash_pin"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."kiosk_users_hash_pin"() TO "service_role";



GRANT ALL ON FUNCTION "public"."kiosk_users_sync_team_name"() TO "anon";
GRANT ALL ON FUNCTION "public"."kiosk_users_sync_team_name"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."kiosk_users_sync_team_name"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_key_id"("bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";



REVOKE ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "public"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";



GRANT ALL ON FUNCTION "public"."set_kiosk_user_pin"("p_user_id" bigint, "p_site_id" bigint, "p_pin" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."set_kiosk_user_pin"("p_user_id" bigint, "p_site_id" bigint, "p_pin" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_kiosk_user_pin"("p_user_id" bigint, "p_site_id" bigint, "p_pin" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."set_pir_document_status"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_pir_document_status"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_pir_document_status"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."signup_create_site"("p_site_name" "text", "p_city" "text", "p_full_name" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) TO "anon";
GRANT ALL ON FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) TO "authenticated";
GRANT ALL ON FUNCTION "public"."site_belongs_to_current_org"("check_site_id" bigint) TO "service_role";



GRANT ALL ON FUNCTION "public"."submission_rows_sync_check_type_text"() TO "anon";
GRANT ALL ON FUNCTION "public"."submission_rows_sync_check_type_text"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."submission_rows_sync_check_type_text"() TO "service_role";



GRANT ALL ON FUNCTION "public"."submissions_sync_staff_name"() TO "anon";
GRANT ALL ON FUNCTION "public"."submissions_sync_staff_name"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."submissions_sync_staff_name"() TO "service_role";



GRANT ALL ON FUNCTION "public"."teams_cascade_name_to_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."teams_cascade_name_to_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."teams_cascade_name_to_users"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "service_role";


















GRANT ALL ON TABLE "public"."check_events" TO "anon";
GRANT ALL ON TABLE "public"."check_events" TO "authenticated";
GRANT ALL ON TABLE "public"."check_events" TO "service_role";



GRANT ALL ON SEQUENCE "public"."check_events_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."check_events_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."check_events_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."check_type_teams" TO "anon";
GRANT ALL ON TABLE "public"."check_type_teams" TO "authenticated";
GRANT ALL ON TABLE "public"."check_type_teams" TO "service_role";



GRANT ALL ON TABLE "public"."check_types" TO "anon";
GRANT ALL ON TABLE "public"."check_types" TO "authenticated";
GRANT ALL ON TABLE "public"."check_types" TO "service_role";



GRANT ALL ON SEQUENCE "public"."check_types_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."check_types_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."check_types_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."item_allowed_types" TO "anon";
GRANT ALL ON TABLE "public"."item_allowed_types" TO "authenticated";
GRANT ALL ON TABLE "public"."item_allowed_types" TO "service_role";



GRANT ALL ON SEQUENCE "public"."item_allowed_types_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."item_allowed_types_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."item_allowed_types_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."items" TO "anon";
GRANT ALL ON TABLE "public"."items" TO "authenticated";
GRANT ALL ON TABLE "public"."items" TO "service_role";



GRANT ALL ON SEQUENCE "public"."items_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."items_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."items_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."kiosk_roles" TO "anon";
GRANT ALL ON TABLE "public"."kiosk_roles" TO "authenticated";
GRANT ALL ON TABLE "public"."kiosk_roles" TO "service_role";



GRANT ALL ON TABLE "public"."kiosk_tokens" TO "anon";
GRANT ALL ON TABLE "public"."kiosk_tokens" TO "authenticated";
GRANT ALL ON TABLE "public"."kiosk_tokens" TO "service_role";



GRANT ALL ON SEQUENCE "public"."kiosk_tokens_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."kiosk_tokens_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."kiosk_tokens_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."kiosk_users" TO "anon";
GRANT ALL ON TABLE "public"."kiosk_users" TO "authenticated";
GRANT ALL ON TABLE "public"."kiosk_users" TO "service_role";



GRANT ALL ON SEQUENCE "public"."kiosk_users_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."kiosk_users_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."kiosk_users_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."teams" TO "anon";
GRANT ALL ON TABLE "public"."teams" TO "authenticated";
GRANT ALL ON TABLE "public"."teams" TO "service_role";



GRANT ALL ON TABLE "public"."kiosk_users_with_team" TO "anon";
GRANT ALL ON TABLE "public"."kiosk_users_with_team" TO "authenticated";
GRANT ALL ON TABLE "public"."kiosk_users_with_team" TO "service_role";



GRANT ALL ON TABLE "public"."pir_documents" TO "anon";
GRANT ALL ON TABLE "public"."pir_documents" TO "authenticated";
GRANT ALL ON TABLE "public"."pir_documents" TO "service_role";



GRANT ALL ON SEQUENCE "public"."pir_documents_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."pir_documents_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."pir_documents_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."profiles" TO "anon";
GRANT ALL ON TABLE "public"."profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."profiles" TO "service_role";



GRANT ALL ON TABLE "public"."role_permissions" TO "anon";
GRANT ALL ON TABLE "public"."role_permissions" TO "authenticated";
GRANT ALL ON TABLE "public"."role_permissions" TO "service_role";



GRANT ALL ON TABLE "public"."rooms" TO "anon";
GRANT ALL ON TABLE "public"."rooms" TO "authenticated";
GRANT ALL ON TABLE "public"."rooms" TO "service_role";



GRANT ALL ON SEQUENCE "public"."rooms_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."rooms_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."rooms_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."submission_rows" TO "anon";
GRANT ALL ON TABLE "public"."submission_rows" TO "authenticated";
GRANT ALL ON TABLE "public"."submission_rows" TO "service_role";



GRANT ALL ON TABLE "public"."submissions" TO "anon";
GRANT ALL ON TABLE "public"."submissions" TO "authenticated";
GRANT ALL ON TABLE "public"."submissions" TO "service_role";



GRANT ALL ON TABLE "public"."v_last_submission" TO "anon";
GRANT ALL ON TABLE "public"."v_last_submission" TO "authenticated";
GRANT ALL ON TABLE "public"."v_last_submission" TO "service_role";



GRANT ALL ON TABLE "public"."schedules_view" TO "anon";
GRANT ALL ON TABLE "public"."schedules_view" TO "authenticated";
GRANT ALL ON TABLE "public"."schedules_view" TO "service_role";



GRANT ALL ON TABLE "public"."site_invites" TO "anon";
GRANT ALL ON TABLE "public"."site_invites" TO "authenticated";
GRANT ALL ON TABLE "public"."site_invites" TO "service_role";



GRANT ALL ON SEQUENCE "public"."site_invites_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."site_invites_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."site_invites_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."sites" TO "anon";
GRANT ALL ON TABLE "public"."sites" TO "authenticated";
GRANT ALL ON TABLE "public"."sites" TO "service_role";



GRANT ALL ON SEQUENCE "public"."sites_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."sites_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."sites_id_seq" TO "service_role";



GRANT ALL ON SEQUENCE "public"."submission_rows_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."submission_rows_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."submission_rows_id_seq" TO "service_role";



GRANT ALL ON SEQUENCE "public"."submissions_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."submissions_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."submissions_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."surgery_settings" TO "anon";
GRANT ALL ON TABLE "public"."surgery_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."surgery_settings" TO "service_role";



GRANT ALL ON SEQUENCE "public"."surgery_settings_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."surgery_settings_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."surgery_settings_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."team_members" TO "anon";
GRANT ALL ON TABLE "public"."team_members" TO "authenticated";
GRANT ALL ON TABLE "public"."team_members" TO "service_role";



GRANT ALL ON SEQUENCE "public"."teams_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."teams_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."teams_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."training_records" TO "anon";
GRANT ALL ON TABLE "public"."training_records" TO "authenticated";
GRANT ALL ON TABLE "public"."training_records" TO "service_role";



GRANT ALL ON SEQUENCE "public"."training_records_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."training_records_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."training_records_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."training_types" TO "anon";
GRANT ALL ON TABLE "public"."training_types" TO "authenticated";
GRANT ALL ON TABLE "public"."training_types" TO "service_role";



GRANT ALL ON SEQUENCE "public"."training_types_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."training_types_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."training_types_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."user_permissions" TO "anon";
GRANT ALL ON TABLE "public"."user_permissions" TO "authenticated";
GRANT ALL ON TABLE "public"."user_permissions" TO "service_role";



GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_item_check_latest" TO "anon";
GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_item_check_latest" TO "authenticated";
GRANT ALL ON TABLE "public"."v_item_check_latest" TO "service_role";



GRANT ALL ON TABLE "public"."v_item_check_status" TO "anon";
GRANT ALL ON TABLE "public"."v_item_check_status" TO "authenticated";
GRANT ALL ON TABLE "public"."v_item_check_status" TO "service_role";



GRANT ALL ON TABLE "public"."v_item_check_summary" TO "anon";
GRANT ALL ON TABLE "public"."v_item_check_summary" TO "authenticated";
GRANT ALL ON TABLE "public"."v_item_check_summary" TO "service_role";



GRANT ALL ON TABLE "public"."v_item_schedule_resolved" TO "anon";
GRANT ALL ON TABLE "public"."v_item_schedule_resolved" TO "authenticated";
GRANT ALL ON TABLE "public"."v_item_schedule_resolved" TO "service_role";



GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_items_admin" TO "anon";
GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_items_admin" TO "authenticated";
GRANT ALL ON TABLE "public"."v_items_admin" TO "service_role";



GRANT ALL ON TABLE "public"."v_kiosk_users_with_manager" TO "anon";
GRANT ALL ON TABLE "public"."v_kiosk_users_with_manager" TO "authenticated";
GRANT ALL ON TABLE "public"."v_kiosk_users_with_manager" TO "service_role";



GRANT ALL ON TABLE "public"."v_my_profile" TO "anon";
GRANT ALL ON TABLE "public"."v_my_profile" TO "authenticated";
GRANT ALL ON TABLE "public"."v_my_profile" TO "service_role";



GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_submission_detail" TO "anon";
GRANT SELECT,REFERENCES,MAINTAIN ON TABLE "public"."v_submission_detail" TO "authenticated";
GRANT ALL ON TABLE "public"."v_submission_detail" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";






























RESET ALL;
